(globalThis.webpackChunksuperset=globalThis.webpackChunksuperset||[]).push([[9541],{90233:(e,t,a)=>{"use strict";a.d(t,{Lu:()=>l,tL:()=>s});var o=a(87462),r=a(76826),n=a.n(r),s={CASE_SENSITIVE_EQUAL:7,EQUAL:6,STARTS_WITH:5,WORD_STARTS_WITH:4,CONTAINS:3,ACRONYM:2,MATCHES:1,NO_MATCH:0};l.rankings=s;var i=function(e,t){return String(e.rankedValue).localeCompare(String(t.rankedValue))};function l(e,t,a){void 0===a&&(a={});var r=a,n=r.keys,l=r.threshold,d=void 0===l?s.MATCHES:l,h=r.baseSort,m=void 0===h?i:h,g=r.sorter,f=void 0===g?function(e){return e.sort((function(e,t){return function(e,t,a){var o=e.rank,r=e.keyIndex,n=t.rank,s=t.keyIndex;return o===n?r===s?a(e,t):r<s?-1:1:o>n?-1:1}(e,t,m)}))}:g,v=e.reduce((function(e,r,i){var l=function(e,t,a,o){return t?function(e,t){for(var a=[],o=0,r=t.length;o<r;o++)for(var n=t[o],s=p(n),i=u(e,n),l=0,c=i.length;l<c;l++)a.push({itemValue:i[l],attributes:s});return a}(e,t).reduce((function(e,t,r){var n=e.rank,i=e.rankedValue,l=e.keyIndex,d=e.keyThreshold,u=t.itemValue,h=t.attributes,p=c(u,a,o),m=i,g=h.minRanking,f=h.maxRanking,v=h.threshold;return p<g&&p>=s.MATCHES?p=g:p>f&&(p=f),p>n&&(n=p,l=r,d=v,m=u),{rankedValue:m,rank:n,keyIndex:l,keyThreshold:d}}),{rankedValue:e,rank:s.NO_MATCH,keyIndex:-1,keyThreshold:o.threshold}):{rankedValue:e,rank:c(e,a,o),keyIndex:-1,keyThreshold:o.threshold}}(r,n,t,a),h=l.rank,m=l.keyThreshold;return h>=(void 0===m?d:m)&&e.push((0,o.Z)({},l,{item:r,index:i})),e}),[]);return f(v).map((function(e){return e.item}))}function c(e,t,a){return e=d(e,a),(t=d(t,a)).length>e.length?s.NO_MATCH:e===t?s.CASE_SENSITIVE_EQUAL:(e=e.toLowerCase())===(t=t.toLowerCase())?s.EQUAL:e.startsWith(t)?s.STARTS_WITH:e.includes(" "+t)?s.WORD_STARTS_WITH:e.includes(t)?s.CONTAINS:1===t.length?s.NO_MATCH:(o=e,r="",o.split(" ").forEach((function(e){e.split("-").forEach((function(e){r+=e.substr(0,1)}))})),r).includes(t)?s.ACRONYM:function(e,t){var a=0,o=0;function r(e,t,o){for(var r=o,n=t.length;r<n;r++)if(t[r]===e)return a+=1,r+1;return-1}var n,i,l=r(t[0],e,0);if(l<0)return s.NO_MATCH;o=l;for(var c=1,d=t.length;c<d;c++)if(!((o=r(t[c],e,o))>-1))return s.NO_MATCH;return n=1/(o-l),i=a/t.length,s.MATCHES+i*n}(e,t);var o,r}function d(e,t){return e=""+e,t.keepDiacritics||(e=n()(e)),e}function u(e,t){var a;if("object"==typeof t&&(t=t.key),"function"==typeof t)a=t(e);else if(null==e)a=null;else if(Object.hasOwnProperty.call(e,t))a=e[t];else{if(t.includes("."))return function(e,t){for(var a=e.split("."),o=[t],r=0,n=a.length;r<n;r++){for(var s=a[r],i=[],l=0,c=o.length;l<c;l++){var d=o[l];if(null!=d)if(Object.hasOwnProperty.call(d,s)){var u=d[s];null!=u&&i.push(u)}else"*"===s&&(i=i.concat(d))}o=i}if(Array.isArray(o[0])){var h=[];return h.concat.apply(h,o)}return o}(t,e);a=null}return null==a?[]:Array.isArray(a)?a:[String(a)]}var h={maxRanking:1/0,minRanking:-1/0};function p(e){return"string"==typeof e?h:(0,o.Z)({},h,e)}},76826:e=>{var t={À:"A",Á:"A",Â:"A",Ã:"A",Ä:"A",Å:"A",Ấ:"A",Ắ:"A",Ẳ:"A",Ẵ:"A",Ặ:"A",Æ:"AE",Ầ:"A",Ằ:"A",Ȃ:"A",Ç:"C",Ḉ:"C",È:"E",É:"E",Ê:"E",Ë:"E",Ế:"E",Ḗ:"E",Ề:"E",Ḕ:"E",Ḝ:"E",Ȇ:"E",Ì:"I",Í:"I",Î:"I",Ï:"I",Ḯ:"I",Ȋ:"I",Ð:"D",Ñ:"N",Ò:"O",Ó:"O",Ô:"O",Õ:"O",Ö:"O",Ø:"O",Ố:"O",Ṍ:"O",Ṓ:"O",Ȏ:"O",Ù:"U",Ú:"U",Û:"U",Ü:"U",Ý:"Y",à:"a",á:"a",â:"a",ã:"a",ä:"a",å:"a",ấ:"a",ắ:"a",ẳ:"a",ẵ:"a",ặ:"a",æ:"ae",ầ:"a",ằ:"a",ȃ:"a",ç:"c",ḉ:"c",è:"e",é:"e",ê:"e",ë:"e",ế:"e",ḗ:"e",ề:"e",ḕ:"e",ḝ:"e",ȇ:"e",ì:"i",í:"i",î:"i",ï:"i",ḯ:"i",ȋ:"i",ð:"d",ñ:"n",ò:"o",ó:"o",ô:"o",õ:"o",ö:"o",ø:"o",ố:"o",ṍ:"o",ṓ:"o",ȏ:"o",ù:"u",ú:"u",û:"u",ü:"u",ý:"y",ÿ:"y",Ā:"A",ā:"a",Ă:"A",ă:"a",Ą:"A",ą:"a",Ć:"C",ć:"c",Ĉ:"C",ĉ:"c",Ċ:"C",ċ:"c",Č:"C",č:"c",C̆:"C",c̆:"c",Ď:"D",ď:"d",Đ:"D",đ:"d",Ē:"E",ē:"e",Ĕ:"E",ĕ:"e",Ė:"E",ė:"e",Ę:"E",ę:"e",Ě:"E",ě:"e",Ĝ:"G",Ǵ:"G",ĝ:"g",ǵ:"g",Ğ:"G",ğ:"g",Ġ:"G",ġ:"g",Ģ:"G",ģ:"g",Ĥ:"H",ĥ:"h",Ħ:"H",ħ:"h",Ḫ:"H",ḫ:"h",Ĩ:"I",ĩ:"i",Ī:"I",ī:"i",Ĭ:"I",ĭ:"i",Į:"I",į:"i",İ:"I",ı:"i",Ĳ:"IJ",ĳ:"ij",Ĵ:"J",ĵ:"j",Ķ:"K",ķ:"k",Ḱ:"K",ḱ:"k",K̆:"K",k̆:"k",Ĺ:"L",ĺ:"l",Ļ:"L",ļ:"l",Ľ:"L",ľ:"l",Ŀ:"L",ŀ:"l",Ł:"l",ł:"l",Ḿ:"M",ḿ:"m",M̆:"M",m̆:"m",Ń:"N",ń:"n",Ņ:"N",ņ:"n",Ň:"N",ň:"n",ŉ:"n",N̆:"N",n̆:"n",Ō:"O",ō:"o",Ŏ:"O",ŏ:"o",Ő:"O",ő:"o",Œ:"OE",œ:"oe",P̆:"P",p̆:"p",Ŕ:"R",ŕ:"r",Ŗ:"R",ŗ:"r",Ř:"R",ř:"r",R̆:"R",r̆:"r",Ȓ:"R",ȓ:"r",Ś:"S",ś:"s",Ŝ:"S",ŝ:"s",Ş:"S",Ș:"S",ș:"s",ş:"s",Š:"S",š:"s",Ţ:"T",ţ:"t",ț:"t",Ț:"T",Ť:"T",ť:"t",Ŧ:"T",ŧ:"t",T̆:"T",t̆:"t",Ũ:"U",ũ:"u",Ū:"U",ū:"u",Ŭ:"U",ŭ:"u",Ů:"U",ů:"u",Ű:"U",ű:"u",Ų:"U",ų:"u",Ȗ:"U",ȗ:"u",V̆:"V",v̆:"v",Ŵ:"W",ŵ:"w",Ẃ:"W",ẃ:"w",X̆:"X",x̆:"x",Ŷ:"Y",ŷ:"y",Ÿ:"Y",Y̆:"Y",y̆:"y",Ź:"Z",ź:"z",Ż:"Z",ż:"z",Ž:"Z",ž:"z",ſ:"s",ƒ:"f",Ơ:"O",ơ:"o",Ư:"U",ư:"u",Ǎ:"A",ǎ:"a",Ǐ:"I",ǐ:"i",Ǒ:"O",ǒ:"o",Ǔ:"U",ǔ:"u",Ǖ:"U",ǖ:"u",Ǘ:"U",ǘ:"u",Ǚ:"U",ǚ:"u",Ǜ:"U",ǜ:"u",Ứ:"U",ứ:"u",Ṹ:"U",ṹ:"u",Ǻ:"A",ǻ:"a",Ǽ:"AE",ǽ:"ae",Ǿ:"O",ǿ:"o",Þ:"TH",þ:"th",Ṕ:"P",ṕ:"p",Ṥ:"S",ṥ:"s",X́:"X",x́:"x",Ѓ:"Г",ѓ:"г",Ќ:"К",ќ:"к",A̋:"A",a̋:"a",E̋:"E",e̋:"e",I̋:"I",i̋:"i",Ǹ:"N",ǹ:"n",Ồ:"O",ồ:"o",Ṑ:"O",ṑ:"o",Ừ:"U",ừ:"u",Ẁ:"W",ẁ:"w",Ỳ:"Y",ỳ:"y",Ȁ:"A",ȁ:"a",Ȅ:"E",ȅ:"e",Ȉ:"I",ȉ:"i",Ȍ:"O",ȍ:"o",Ȑ:"R",ȑ:"r",Ȕ:"U",ȕ:"u",B̌:"B",b̌:"b",Č̣:"C",č̣:"c",Ê̌:"E",ê̌:"e",F̌:"F",f̌:"f",Ǧ:"G",ǧ:"g",Ȟ:"H",ȟ:"h",J̌:"J",ǰ:"j",Ǩ:"K",ǩ:"k",M̌:"M",m̌:"m",P̌:"P",p̌:"p",Q̌:"Q",q̌:"q",Ř̩:"R",ř̩:"r",Ṧ:"S",ṧ:"s",V̌:"V",v̌:"v",W̌:"W",w̌:"w",X̌:"X",x̌:"x",Y̌:"Y",y̌:"y",A̧:"A",a̧:"a",B̧:"B",b̧:"b",Ḑ:"D",ḑ:"d",Ȩ:"E",ȩ:"e",Ɛ̧:"E",ɛ̧:"e",Ḩ:"H",ḩ:"h",I̧:"I",i̧:"i",Ɨ̧:"I",ɨ̧:"i",M̧:"M",m̧:"m",O̧:"O",o̧:"o",Q̧:"Q",q̧:"q",U̧:"U",u̧:"u",X̧:"X",x̧:"x",Z̧:"Z",z̧:"z"},a=Object.keys(t).join("|"),o=new RegExp(a,"g"),r=new RegExp(a,""),n=function(e){return e.replace(o,(function(e){return t[e]}))};e.exports=n,e.exports.has=function(e){return!!e.match(r)},e.exports.remove=n},39069:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>Xt});var o=a(67294),r=a(37703),n=a(61988),s=a(22102),i=a(38703);const l={form_data:{name:"form_data",parser:e=>{const t=JSON.parse(e);if(t.datasource){const[e,a]=t.datasource.split("__");t.dataset_id=e,t.dataset_type=a,delete t.datasource}return t}},slice_id:{name:"slice_id"},dataset_id:{name:"dataset_id"},dataset_type:{name:"dataset_type"},datasource:{name:"datasource",parser:e=>{const[t,a]=e.split("__");return{dataset_id:t,dataset_type:a}}},form_data_key:{name:"form_data_key"},permalink_key:{name:"permalink_key"},viz_type:{name:"viz_type"},dashboard_id:{name:"dashboard_id"}},c={p:"permalink_key",table:"dataset_id"},d=()=>{const e=new URLSearchParams(window.location.search);return Object.keys(l).reduce(((t,a)=>{const o=e.get(a);if(null===o)return t;let r;try{var n,s,i;r=null!=(n=null==(s=(i=l[a]).parser)?void 0:s.call(i,o))?n:o}catch{r=o}return"object"==typeof r?{...t,...r}:{...t,[l[a].name]:r}}),{})};var u=a(76445),h=a(11965),p=a(5872),m=a.n(p),g=a(78718),f=a.n(g),v=a(23279),b=a.n(v),y=a(45697),S=a.n(y),w=a(14890),_=a(51995),x=a(68492),Z=a(29119),k=a(28615),C=a(14278),T=a(58593),N=a(60812),$=a(33626),I=a(70163),D=a(61337),R=a(27600),E=a(99543),A=a(97381),O=a(3741),U=a(23525),z=a(94184),M=a.n(z),j=a(52256),F=a(50810),q=a(2275),L=a(1510),Q=a(40219),P=a(99068),K=a(12515),B=a(10331),H=a(651),V=a(19485),W=a(6954),J=a(40323),Y=a(55786),G=a(31069),X=a(99612),ee=a(18239),te=a(48251),ae=a(89555),oe=a(37921),re=a(30381),ne=a.n(re);const se=({cachedTimestamp:e})=>{const t=e?(0,h.tZ)("span",null,(0,n.t)("Loaded data cached"),(0,h.tZ)("b",null," ",ne().utc(e).fromNow())):(0,n.t)("Loaded from cache");return(0,h.tZ)("span",null,t,". ",(0,n.t)("Click to force-refresh"))},ie=({className:e,onClick:t,cachedTimestamp:a})=>{const[r,s]=(0,o.useState)(!1),i=r?"primary":"default";return(0,h.tZ)(T.u,{title:(0,h.tZ)(se,{cachedTimestamp:a}),id:"cache-desc-tooltip"},(0,h.tZ)(oe.Z,{className:`${e}`,type:i,onClick:t,onMouseOver:()=>s(!0),onMouseOut:()=>s(!1)},(0,n.t)("Cached")," ",(0,h.tZ)("i",{className:"fa fa-refresh"})))};var le=a(44814);const ce=(0,_.iK)(oe.Z)`
  text-align: left;
`;function de({endTime:e,isRunning:t,startTime:a,status:r="success"}){const[n,s]=(0,o.useState)("00:00:00.00"),i=(0,o.useRef)();return(0,o.useEffect)((()=>{const o=()=>{i.current&&(clearInterval(i.current),i.current=void 0)};return t&&(i.current=setInterval((()=>{if(a){const r=e||(0,le.zO)();a<r&&s((0,le.zQ)(a,r)),t||o()}}),30)),o}),[e,t,a]),(0,h.tZ)(ce,{type:r,role:"timer"},n)}var ue;!function(e){e.failed="danger",e.loading="warning",e.success="success"}(ue||(ue={}));const he=(0,o.forwardRef)((({queriesResponse:e,chartStatus:t,chartUpdateStartTime:a,chartUpdateEndTime:o,refreshCachedQuery:r,rowLimit:n},s)=>{const i="loading"===t,l=null==e?void 0:e[0];return(0,h.tZ)("div",{ref:s},(0,h.tZ)("div",{css:e=>h.iv`
            display: flex;
            justify-content: flex-end;
            padding-bottom: ${4*e.gridUnit}px;
            & .ant-tag:last-of-type {
              margin: 0;
            }
          `},!i&&l&&(0,h.tZ)(ae.Z,{rowcount:Number(l.rowcount)||0,limit:Number(n)||0}),!i&&(null==l?void 0:l.is_cached)&&(0,h.tZ)(ie,{onClick:r,cachedTimestamp:l.cached_dttm}),(0,h.tZ)(de,{startTime:a,endTime:o,isRunning:i,status:ue[t]})))}));var pe=a(35932);const me=_.iK.div`
  ${({theme:e})=>h.iv`
    margin: ${4*e.gridUnit}px;
    padding: ${4*e.gridUnit}px;

    border: 1px solid ${e.colors.info.base};
    background-color: ${e.colors.info.light2};
    border-radius: 2px;

    color: ${e.colors.info.dark2};
    font-size: ${e.typography.sizes.m}px;

    p {
      margin-bottom: ${e.gridUnit}px;
    }

    & a,
    & span[role='button'] {
      color: inherit;
      text-decoration: underline;
      &:hover {
        color: ${e.colors.info.dark1};
      }
    }

    &.alert-type-warning {
      border-color: ${e.colors.alert.base};
      background-color: ${e.colors.alert.light2};

      p {
        color: ${e.colors.alert.dark2};
      }

      & a:hover,
      & span[role='button']:hover {
        color: ${e.colors.alert.dark1};
      }
    }
  `}
`,ge=_.iK.div`
  display: flex;
  justify-content: flex-end;
  button {
    line-height: 1;
  }
`,fe=_.iK.p`
  font-weight: ${({theme:e})=>e.typography.weights.bold};
`,ve=(0,o.forwardRef)((({title:e,bodyText:t,primaryButtonAction:a,secondaryButtonAction:o,primaryButtonText:r,secondaryButtonText:n,type:s="info",className:i=""},l)=>(0,h.tZ)(me,{className:`alert-type-${s} ${i}`,ref:l},(0,h.tZ)(fe,null,e),(0,h.tZ)("p",null,t),r&&a&&(0,h.tZ)(ge,null,o&&n&&(0,h.tZ)(pe.Z,{buttonStyle:"link",buttonSize:"small",onClick:o},n),(0,h.tZ)(pe.Z,{buttonStyle:"warning"===s?"warning":"primary",buttonSize:"small",onClick:a},r)))));var be=a(75701);const ye={actions:S().object.isRequired,onQuery:S().func,can_overwrite:S().bool.isRequired,can_download:S().bool.isRequired,datasource:S().object,dashboardId:S().number,column_formats:S().object,containerId:S().string.isRequired,isStarred:S().bool.isRequired,slice:S().object,sliceName:S().string,table_name:S().string,vizType:S().string.isRequired,form_data:S().object,ownState:S().object,standalone:S().number,force:S().bool,timeout:S().number,chartIsStale:S().bool,chart:q.$6,errorMessage:S().node,triggerRender:S().bool},Se=1.25,we=[100,0],_e=[300,65],xe=_.iK.div`
  display: flex;
  flex-direction: column;
  align-items: stretch;
  align-content: stretch;
  overflow: auto;
  box-shadow: none;
  height: 100%;

  & > div {
    height: 100%;
  }

  .gutter {
    border-top: 1px solid ${({theme:e})=>e.colors.grayscale.light2};
    border-bottom: 1px solid ${({theme:e})=>e.colors.grayscale.light2};
    width: ${({theme:e})=>9*e.gridUnit}px;
    margin: ${({theme:e})=>e.gridUnit*Se}px auto;
  }

  .gutter.gutter-vertical {
    cursor: row-resize;
  }

  .ant-collapse {
    .ant-tabs {
      height: 100%;
      .ant-tabs-nav {
        padding-left: ${({theme:e})=>5*e.gridUnit}px;
        margin: 0;
      }
      .ant-tabs-content-holder {
        overflow: hidden;
        .ant-tabs-content {
          height: 100%;
        }
      }
    }
  }
`,Ze=({chart:e,slice:t,vizType:a,ownState:r,triggerRender:s,force:i,datasource:l,errorMessage:c,form_data:d,onQuery:u,actions:p,timeout:m,standalone:g,chartIsStale:f,chartAlert:v})=>{const b=(0,_.Fg)(),y=b.gridUnit*Se,S=b.gridUnit*Se,{width:w,height:x,ref:Z}=(0,X.NB)({refreshMode:"debounce",refreshRate:300}),[k,C]=(0,o.useState)((0,D.rV)(D.dR.chart_split_sizes,we)),T=!v&&f&&"failed"!==e.chartStatus&&(0,Y.Z)(e.queriesResponse).length>0,N=(0,o.useCallback)((async function(){if(t&&null===t.query_context){const e=(0,K.u)({formData:t.form_data,force:i,resultFormat:"json",resultType:"full",setDataMask:null,ownState:null});await G.Z.put({endpoint:`/api/v1/chart/${t.slice_id}`,headers:{"Content-Type":"application/json"},body:JSON.stringify({query_context:JSON.stringify(e),query_context_generation:!0})})}}),[t]);(0,o.useEffect)((()=>{N()}),[N]),(0,o.useEffect)((()=>{(0,D.LS)(D.dR.chart_split_sizes,k)}),[k]);const $=(0,o.useCallback)((e=>{C(e)}),[]),I=(0,o.useCallback)((()=>{p.setForceQuery(!0),p.postChartFormData(d,!0,m,e.id,void 0,r),p.updateQueryFormData(d,e.id)}),[p,e.id,d,r,m]),R=(0,o.useCallback)((e=>{let t;t=e?[60,40]:we,C(t)}),[]),E=(0,o.useCallback)((()=>(0,h.tZ)("div",{css:h.iv`
          min-height: 0;
          flex: 1;
          overflow: auto;
        `,ref:Z},w&&x&&(0,h.tZ)(ee.Z,{width:Math.floor(w),height:x,ownState:r,annotationData:e.annotationData,chartAlert:e.chartAlert,chartStackTrace:e.chartStackTrace,chartId:e.id,chartStatus:e.chartStatus,triggerRender:s,force:i,datasource:l,errorMessage:c,formData:d,latestQueryFormData:e.latestQueryFormData,onQuery:u,queriesResponse:e.queriesResponse,chartIsStale:f,setControlValue:p.setControlValue,timeout:m,triggerQuery:e.triggerQuery,vizType:a}))),[p.setControlValue,e.annotationData,e.chartAlert,e.chartStackTrace,e.chartStatus,e.id,e.latestQueryFormData,e.queriesResponse,e.triggerQuery,f,x,Z,w,l,c,i,d,u,r,m,s,a]),A=(0,o.useMemo)((()=>(0,h.tZ)("div",{className:"panel-body",css:h.iv`
          display: flex;
          flex-direction: column;
        `},T&&(0,h.tZ)(ve,{title:c?(0,n.t)("Required control values have been removed"):(0,n.t)("Your chart is not up to date"),bodyText:c?(0,be.J)(!1):(0,h.tZ)("span",null,(0,n.t)('You updated the values in the control panel, but the chart was not updated automatically. Run the query by clicking on the "Update chart" button or')," ",(0,h.tZ)("span",{role:"button",tabIndex:0,onClick:u},(0,n.t)("click here")),"."),type:"warning",css:e=>h.iv`
              margin: 0 0 ${4*e.gridUnit}px 0;
            `}),(0,h.tZ)(he,{queriesResponse:e.queriesResponse,chartStatus:e.chartStatus,chartUpdateStartTime:e.chartUpdateStartTime,chartUpdateEndTime:e.chartUpdateEndTime,refreshCachedQuery:I,rowLimit:null==d?void 0:d.row_limit}),E())),[T,c,u,e.queriesResponse,e.chartStatus,e.chartUpdateStartTime,e.chartUpdateEndTime,I,null==d?void 0:d.row_limit,E]),O=(0,o.useMemo)((()=>E()),[E]),[U,z]=(0,o.useState)(e.latestQueryFormData);(0,o.useEffect)((()=>{s||z(e.latestQueryFormData)}),[e.latestQueryFormData]);const M=(0,o.useCallback)(((e,t,a)=>({[e]:`calc(${t}% - ${a+y}px)`})),[y]);if(g){const e="background-transparent";return document.body.className.split(" ").includes(e)||(document.body.className+=` ${e}`),O}return(0,h.tZ)(xe,{className:"panel panel-default chart-container"},"filter_box"===a?A:(0,h.tZ)(J.Z,{sizes:k,minSize:_e,direction:"vertical",gutterSize:S,onDragEnd:$,elementStyle:M,expandToMin:!0},A,(0,h.tZ)(te.c9,{ownState:r,queryFormData:U,datasource:l,queryForce:i,onCollapseChange:R,chartStatus:e.chartStatus,errorMessage:c,actions:p})))};Ze.propTypes=ye;const ke=Ze;var Ce=a(37687),Te=a(85481),Ne=a(9882),$e=a(43700),Ie=a(71262),De=a(49484),Re=a(61357),Ee=a(41030);const Ae=({loading:e,onQuery:t,onStop:a,errorMessage:o,isNewChart:r,canStopQuery:s,chartIsStale:i})=>e?(0,h.tZ)(pe.Z,{onClick:a,buttonStyle:"warning",disabled:!s},(0,h.tZ)("i",{className:"fa fa-stop-circle-o"})," ",(0,n.t)("Stop")):(0,h.tZ)(pe.Z,{onClick:t,buttonStyle:i?"primary":"secondary",disabled:!!o},r?(0,n.t)("Create chart"):(0,n.t)("Update chart")),Oe=e=>h.iv`
  display: flex;
  position: sticky;
  bottom: 0;
  flex-direction: column;
  align-items: center;
  padding: ${4*e.gridUnit}px;
  z-index: 999;
  background: linear-gradient(
    ${(0,De.rgba)(e.colors.grayscale.light5,0)},
    ${e.colors.grayscale.light5} ${e.opacity.mediumLight}
  );

  & > button {
    min-width: 156px;
  }
`,Ue=_.iK.div`
  position: relative;
  height: 100%;
  width: 100%;

  // Resizable add overflow-y: auto as a style to this div
  // To override it, we need to use !important
  overflow: visible !important;
  #controlSections {
    height: 100%;
    overflow: visible;
  }
  .nav-tabs {
    flex: 0 0 1;
  }
  .tab-content {
    overflow: auto;
    flex: 1 1 100%;
  }
  .Select__menu {
    max-width: 100%;
  }
  .type-label {
    margin-right: ${({theme:e})=>3*e.gridUnit}px;
    width: ${({theme:e})=>7*e.gridUnit}px;
    display: inline-block;
    text-align: center;
    font-weight: ${({theme:e})=>e.typography.weights.bold};
  }
`,ze=(0,_.iK)(Ie.ZP)`
  ${({theme:e,fullWidth:t})=>h.iv`
    height: 100%;
    overflow: visible;
    .ant-tabs-nav {
      margin-bottom: 0;
    }
    .ant-tabs-nav-list {
      width: ${t?"100%":"50%"};
    }
    .ant-tabs-tabpane {
      height: 100%;
    }
    .ant-tabs-content-holder {
      padding-top: ${4*e.gridUnit}px;
    }

    .ant-collapse-ghost > .ant-collapse-item {
      &:not(:last-child) {
        border-bottom: 1px solid ${e.colors.grayscale.light3};
      }

      & > .ant-collapse-header {
        font-size: ${e.typography.sizes.s}px;
      }

      & > .ant-collapse-content > .ant-collapse-content-box {
        padding-bottom: 0;
        font-size: ${e.typography.sizes.s}px;
      }
    }
  `}
`,Me=(e,t)=>e.reduce(((e,a)=>!a.expanded||(e=>!!e.label&&(Te.sections.legacyRegularTime.label===e.label||Te.sections.legacyTimeseriesTime.label===e.label))(a)&&!(e=>{var t;return null==e||null==(t=e.columns)?void 0:t.some((e=>e.is_dttm))})(t)?e:[...e,String(a.label)]),[]),je=e=>{var t,a;const r=(0,o.useContext)(C.Zn),s=(0,N.D)(e.exploreState),l=(0,N.D)(e.exploreState.datasource),[c,d]=(0,o.useState)(!1),u=(0,o.useRef)(null);(0,o.useEffect)((()=>{var t,a,o;!l||(null==(t=e.exploreState.datasource)?void 0:t.id)===l.id&&(null==(a=e.exploreState.datasource)?void 0:a.type)===l.type||(d(!0),null==(o=u.current)||o.scrollTo(0,0))}),[null==(t=e.exploreState.datasource)?void 0:t.id,null==(a=e.exploreState.datasource)?void 0:a.type,l]);const{expandedQuerySections:p,expandedCustomizeSections:g,querySections:f,customizeSections:v}=(0,o.useMemo)((()=>function(e,t,a){const o=[],r=[];return(0,B.Bq)(e,a).forEach((e=>{"data"===e.tabOverride||e.controlSetRows.some((e=>e.some((e=>e&&"object"==typeof e&&"config"in e&&e.config&&(!e.config.renderTrigger||"data"===e.config.tabOverride)))))?o.push(e):r.push(e)})),{expandedQuerySections:Me(o,t),expandedCustomizeSections:Me(r,t),querySections:o,customizeSections:r}}(e.form_data.viz_type,e.exploreState.datasource,e.datasource_type)),[e.exploreState.datasource,e.form_data.viz_type,e.datasource_type]),b=(0,o.useCallback)((()=>{(0,Y.Z)(e.exploreState.controlsTransferred).forEach((t=>e.actions.setControlValue(t,e.controls[t].default)))}),[e.actions,e.exploreState.controlsTransferred,e.controls]),y=(0,o.useCallback)((()=>{b(),d(!1)}),[b]),S=(0,o.useCallback)((()=>{d(!1)}),[]),w=({name:t,config:a})=>{const{controls:o,chart:r,exploreState:n}=e;return Boolean(null==a.shouldMapStateToProps?void 0:a.shouldMapStateToProps(s||n,n,o[t],r))},_=t=>{const{controls:a}=e,{label:r,description:n}=t,s=String(r),i=t.controlSetRows.some((e=>e.some((e=>{const t="string"==typeof e?e:e&&"name"in e?e.name:null;return t&&t in a&&a[t].validationErrors&&a[t].validationErrors.length>0}))));return(0,h.tZ)($e.Z.Panel,{css:e=>h.iv`
          margin-bottom: 0;
          box-shadow: none;

          &:last-child {
            padding-bottom: ${16*e.gridUnit}px;
            border-bottom: 0;
          }

          .panel-body {
            margin-left: ${4*e.gridUnit}px;
            padding-bottom: 0;
          }

          span.label {
            display: inline-block;
          }
        `,header:(0,h.tZ)((()=>(0,h.tZ)("span",null,(0,h.tZ)("span",{css:e=>h.iv`
            font-size: ${e.typography.sizes.m}px;
            line-height: 1.3;
          `},r)," ",n&&(0,h.tZ)(Ne.V,{label:s,tooltip:n}),i&&(0,h.tZ)(Ne.V,{label:"validation-errors",bsStyle:"danger",tooltip:"This section contains validation errors"}))),null),key:s},t.controlSetRows.map(((t,a)=>{const r=t.map((t=>t?o.isValidElement(t)?t:t.name&&t.config&&"datasource"!==t.name?(({name:t,config:a})=>{const{controls:o,chart:r,exploreState:n}=e,{visibility:s}=a,i={...a,...o[t],...w({name:t,config:a})?null==a||null==a.mapStateToProps?void 0:a.mapStateToProps(n,o[t],r):void 0,name:t},{validationErrors:l,label:c,description:d,...u}=i,p=s?s.call(a,e,i):void 0,g="function"==typeof c?c(n,o[t],r):c,f="function"==typeof d?d(n,o[t],r):d;return(0,h.tZ)(Ee.Z,m()({key:`control-${t}`,name:t,label:g,description:f,validationErrors:l,actions:e.actions,isVisible:p},u))})(t):null:null)).filter((e=>null!==e));return 0===r.length?null:(0,h.tZ)(Re.Z,{key:`controlsetrow-${a}`,controls:r})})))},x=(0,Y.Z)(e.exploreState.controlsTransferred).length>0,Z=(0,o.useCallback)((()=>x?(0,h.tZ)(ve,{title:(0,n.t)("Keep control settings?"),bodyText:(0,n.t)("You've changed datasets. Any controls with data (columns, metrics) that match this new dataset have been retained."),primaryButtonAction:S,secondaryButtonAction:y,primaryButtonText:(0,n.t)("Continue"),secondaryButtonText:(0,n.t)("Clear form"),type:"info"}):(0,h.tZ)(ve,{title:(0,n.t)("No form settings were maintained"),bodyText:(0,n.t)("We were unable to carry over any controls when switching to this new dataset."),primaryButtonAction:S,primaryButtonText:(0,n.t)("Continue"),type:"warning"})),[y,S,x]),k=(0,o.useMemo)((()=>(0,h.tZ)(o.Fragment,null,(0,h.tZ)("span",null,(0,n.t)("Data")),e.errorMessage&&(0,h.tZ)("span",{css:e=>h.iv`
              font-size: ${e.typography.sizes.xs}px;
              margin-left: ${2*e.gridUnit}px;
            `}," ",(0,h.tZ)(T.u,{id:"query-error-tooltip",placement:"right",title:e.errorMessage},(0,h.tZ)("i",{className:"fa fa-exclamation-circle text-danger fa-lg"}))))),[e.errorMessage]);if(!(0,Ce.Z)().has(e.form_data.viz_type)&&r.loading)return(0,h.tZ)(i.Z,null);const $=v.length>0;return(0,h.tZ)(Ue,{ref:u},(0,h.tZ)(ze,{id:"controlSections",fullWidth:$,allowOverflow:!1},(0,h.tZ)(Ie.ZP.TabPane,{key:"query",tab:k},(0,h.tZ)($e.Z,{defaultActiveKey:p,expandIconPosition:"right",ghost:!0},c&&(0,h.tZ)(Z,null),f.map(_))),$&&(0,h.tZ)(Ie.ZP.TabPane,{key:"display",tab:(0,n.t)("Customize")},(0,h.tZ)($e.Z,{defaultActiveKey:g,expandIconPosition:"right",ghost:!0},v.map(_)))),(0,h.tZ)("div",{css:Oe},(0,h.tZ)(Ae,{onQuery:e.onQuery,onStop:e.onStop,errorMessage:e.errorMessage,loading:"loading"===e.chart.chartStatus,isNewChart:!e.chart.queriesResponse,canStopQuery:e.canStopQuery,chartIsStale:e.chartIsStale})))};var Fe=a(9875),qe=a(49238),Le=a(29487),Qe=a(30724),Pe=a.n(Qe),Ke=a(74069),Be=a(87183),He=a(26506);const Ve="save_chart_recent_dashboard",We=(0,n.t)("**Select** a dashboard OR **create** a new one"),Je=(0,_.iK)(Ke.Z)`
  .ant-modal-body {
    overflow: visible;
  }
`;class Ye extends o.Component{constructor(e){super(e),this.state={saveToDashboardId:null,newSliceName:e.sliceName,alert:null,action:this.canOverwriteSlice()?"overwrite":"saveas"},this.onDashboardSelectChange=this.onDashboardSelectChange.bind(this),this.onSliceNameChange=this.onSliceNameChange.bind(this),this.changeAction=this.changeAction.bind(this),this.saveOrOverwrite=this.saveOrOverwrite.bind(this),this.isNewDashboard=this.isNewDashboard.bind(this)}isNewDashboard(){return!(this.state.saveToDashboardId||!this.state.newDashboardName)}canOverwriteSlice(){var e,t,a;return(null==(e=this.props.slice)||null==(t=e.owners)?void 0:t.includes(this.props.userId))&&!(null!=(a=this.props.slice)&&a.is_managed_externally)}componentDidMount(){this.props.actions.fetchDashboards(this.props.userId).then((()=>{const e=this.props.dashboards.map((e=>e.value)),t=sessionStorage.getItem(Ve);let a=t&&parseInt(t,10);this.props.dashboardId&&(a=this.props.dashboardId),null!==a&&-1!==e.indexOf(a)&&this.setState({saveToDashboardId:a})}))}onSliceNameChange(e){this.setState({newSliceName:e.target.value})}onDashboardSelectChange(e){const t=e?String(e):void 0,a=e&&"number"==typeof e?e:null;this.setState({saveToDashboardId:a,newDashboardName:t})}changeAction(e){this.setState({action:e})}saveOrOverwrite(e){this.setState({alert:null}),this.props.actions.removeSaveModalAlert();const t={};if(this.props.slice&&this.props.slice.slice_id&&(t.slice_id=this.props.slice.slice_id),"saveas"===t.action&&""===this.state.newSliceName)return void this.setState({alert:(0,n.t)("Please enter a chart name")});t.action=this.state.action,t.slice_name=this.state.newSliceName,t.save_to_dashboard_id=this.state.saveToDashboardId,t.new_dashboard_name=this.state.newDashboardName;const{url_params:a,...o}=this.props.form_data||{};this.props.actions.saveSlice(o,t).then((t=>{null===t.dashboard_id?sessionStorage.removeItem(Ve):sessionStorage.setItem(Ve,t.dashboard_id);let o=e?t.dashboard_url:t.slice.slice_url;if(a){const e=o.includes("?")?"&":"?";o=`${o}${e}${new URLSearchParams(a).toString()}`}window.location.assign(o)})),this.props.onHide()}removeAlert(){this.props.alert&&this.props.actions.removeSaveModalAlert(),this.setState({alert:null})}render(){const e=this.state.saveToDashboardId||this.state.newDashboardName;return(0,h.tZ)(Je,{show:!0,onHide:this.props.onHide,title:(0,n.t)("Save chart"),footer:(0,h.tZ)("div",null,(0,h.tZ)(pe.Z,{id:"btn_cancel",buttonSize:"small",onClick:this.props.onHide},(0,n.t)("Cancel")),(0,h.tZ)(pe.Z,{id:"btn_modal_save_goto_dash",buttonSize:"small",disabled:!this.state.newSliceName||!this.state.saveToDashboardId&&!this.state.newDashboardName,onClick:()=>this.saveOrOverwrite(!0)},this.isNewDashboard()?(0,n.t)("Save & go to new dashboard"):(0,n.t)("Save & go to dashboard")),(0,h.tZ)(pe.Z,{id:"btn_modal_save",buttonSize:"small",buttonStyle:"primary",onClick:()=>this.saveOrOverwrite(!1),disabled:!this.state.newSliceName},!this.canOverwriteSlice()&&this.props.slice?(0,n.t)("Save as new chart"):this.isNewDashboard()?(0,n.t)("Save to new dashboard"):(0,n.t)("Save")))},(0,h.tZ)(qe.l0,{layout:"vertical"},(this.state.alert||this.props.alert)&&(0,h.tZ)(Le.Z,{type:"warning",message:(0,h.tZ)(o.Fragment,null,this.state.alert?this.state.alert:this.props.alert,(0,h.tZ)("i",{role:"button","aria-label":"Remove alert",tabIndex:0,className:"fa fa-close pull-right",onClick:this.removeAlert.bind(this),style:{cursor:"pointer"}}))}),(0,h.tZ)(qe.xJ,null,(0,h.tZ)(Be.Y,{id:"overwrite-radio",disabled:!this.canOverwriteSlice(),checked:"overwrite"===this.state.action,onChange:()=>this.changeAction("overwrite")},(0,n.t)("Save (Overwrite)")),(0,h.tZ)(Be.Y,{id:"saveas-radio",checked:"saveas"===this.state.action,onChange:()=>this.changeAction("saveas")},(0,n.t)("Save as..."))),(0,h.tZ)("hr",null),(0,h.tZ)(qe.xJ,{label:(0,n.t)("Chart name"),required:!0},(0,h.tZ)(Fe.II,{name:"new_slice_name",type:"text",placeholder:"Name",value:this.state.newSliceName,onChange:this.onSliceNameChange})),(0,h.tZ)(qe.xJ,{label:(0,n.t)("Add to dashboard")},(0,h.tZ)(He.Ph,{allowClear:!0,allowNewOptions:!0,ariaLabel:(0,n.t)("Select a dashboard"),options:this.props.dashboards,onChange:this.onDashboardSelectChange,value:e||void 0,placeholder:(0,h.tZ)(Pe(),{source:We,renderers:{paragraph:"span"}})}))))}}const Ge=(0,r.$j)((function({explore:e,saveModal:t,user:a}){return{datasource:e.datasource,slice:e.slice,userId:null==a?void 0:a.userId,dashboards:t.dashboards,alert:t.saveModalAlert}}),(()=>({})))(Ye);var Xe=a(46078),et=a(90233),tt=a(41331),at=a(91877),ot=a(93185),rt=a(27034),nt=a(42753),st=a(99963);const it=_.iK.div`
  ${({theme:e})=>h.iv`
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    height: ${6*e.gridUnit}px;
    padding: 0 ${e.gridUnit}px;

    // hack to make the drag preview image corners rounded
    transform: translate(0, 0);
    background-color: inherit;
    border-radius: 4px;

    > div {
      min-width: 0;
      margin-right: ${2*e.gridUnit}px;
    }
  `}
`;function lt(e){const{labelRef:t,showTooltip:a,type:o,value:r}=e,[{isDragging:n},s]=(0,rt.c)({item:{value:e.value,type:e.type},collect:e=>({isDragging:e.isDragging()})}),i={labelRef:t,showTooltip:!n&&a,showType:!0};return(0,h.tZ)(it,{ref:s},o===nt.g.Column?(0,h.tZ)(st.l,m()({column:r},i)):(0,h.tZ)(st.B,m()({metric:r},i)),(0,h.tZ)(I.Z.Drag,null))}const ct=(0,at.cr)(ot.T.ENABLE_EXPLORE_DRAG_AND_DROP),dt=_.iK.button`
  background: none;
  border: none;
  text-decoration: underline;
  color: ${({theme:e})=>e.colors.primary.dark1};
`,ut=_.iK.div`
  text-align: center;
  padding-top: 2px;
`,ht=_.iK.div`
  ${({theme:e})=>h.iv`
    background-color: ${e.colors.grayscale.light5};
    position: relative;
    height: 100%;
    display: flex;
    flex-direction: column;
    max-height: 100%;
    .ant-collapse {
      height: auto;
    }
    .field-selections {
      padding: 0 0 ${4*e.gridUnit}px;
      overflow: auto;
    }
    .field-length {
      margin-bottom: ${2*e.gridUnit}px;
      font-size: ${e.typography.sizes.s}px;
      color: ${e.colors.grayscale.light1};
    }
    .form-control.input-md {
      width: calc(100% - ${8*e.gridUnit}px);
      height: ${8*e.gridUnit}px;
      margin: ${2*e.gridUnit}px auto;
    }
    .type-label {
      font-size: ${e.typography.sizes.s}px;
      color: ${e.colors.grayscale.base};
    }
    .Control {
      padding-bottom: 0;
    }
  `};
`,pt=_.iK.div`
  ${({theme:e})=>h.iv`
    overflow: hidden;
    text-overflow: ellipsis;
    font-size: ${e.typography.sizes.s}px;
    background-color: ${e.colors.grayscale.light4};
    margin: ${2*e.gridUnit}px 0;
    border-radius: 4px;
    padding: 0 ${e.gridUnit}px;

    &:first-of-type {
      margin-top: 0;
    }
    &:last-of-type {
      margin-bottom: 0;
    }

    ${ct&&h.iv`
      padding: 0;
      cursor: pointer;
      &:hover {
        background-color: ${e.colors.grayscale.light3};
      }
    `}

    & > span {
      white-space: nowrap;
    }

    .option-label {
      display: inline;
    }

    .metric-option {
      & > svg {
        min-width: ${4*e.gridUnit}px;
      }
      & > .option-label {
        overflow: hidden;
        text-overflow: ellipsis;
      }
    }
  `}
`,mt=_.iK.span`
  ${({theme:e})=>`\n    font-size: ${e.typography.sizes.m}px;\n    line-height: 1.3;\n  `}
`,gt=_.iK.div`
  ${({theme:e})=>h.iv`
    margin: 0 ${2.5*e.gridUnit}px;

    span {
      text-decoration: underline;
    }
  `}
`,ft=e=>{const t={labelRef:(0,o.useRef)(null)};return(0,h.tZ)(pt,{className:e.className},o.cloneElement(e.children,t))};function vt({datasource:e,controls:{datasource:t},actions:a,shouldForceUpdate:r}){const{columns:s,metrics:i}=e,l=(0,o.useMemo)((()=>[...s].sort(((e,t)=>e.is_dttm&&!t.is_dttm?-1:t.is_dttm&&!e.is_dttm?1:0))),[s]),[c,d]=(0,o.useState)(!1),[u,p]=(0,o.useState)(""),[g,f]=(0,o.useState)({columns:l,metrics:i}),[v,y]=(0,o.useState)(!1),[S,w]=(0,o.useState)(!1),_=(0,o.useMemo)((()=>b()((e=>{f(""!==e?{columns:(0,et.Lu)(l,e,{keys:[{key:"verbose_name",threshold:et.tL.CONTAINS},{key:"column_name",threshold:et.tL.CONTAINS},{key:e=>[e.description,e.expression].map((e=>(null==e?void 0:e.replace(/[_\n\s]+/g," "))||"")),threshold:et.tL.CONTAINS,maxRanking:et.tL.CONTAINS}],keepDiacritics:!0}),metrics:(0,et.Lu)(i,e,{keys:[{key:"verbose_name",threshold:et.tL.CONTAINS},{key:"metric_name",threshold:et.tL.CONTAINS},{key:e=>[e.description,e.expression].map((e=>(null==e?void 0:e.replace(/[_\n\s]+/g," "))||"")),threshold:et.tL.CONTAINS,maxRanking:et.tL.CONTAINS}],keepDiacritics:!0,baseSort:(e,t)=>Number(t.item.is_certified)-Number(e.item.is_certified)||String(e.rankedValue).localeCompare(t.rankedValue)})}:{columns:l,metrics:i})}),R.oP)),[l,i]);(0,o.useEffect)((()=>{f({columns:l,metrics:i}),p("")}),[l,e,i]);const x=(0,o.useMemo)((()=>v?g.metrics:g.metrics.slice(0,50)),[g.metrics,v]),Z=(0,o.useMemo)((()=>(S?g.columns:g.columns.slice(0,50)).sort(((e,t)=>t.is_certified-e.is_certified))),[g.columns,S]),k=(0,o.useMemo)((()=>(0,h.tZ)(o.Fragment,null,(0,h.tZ)(Fe.II,{allowClear:!0,onChange:e=>{p(e.target.value),_(e.target.value)},value:u,className:"form-control input-md",placeholder:(0,n.t)("Search Metrics & Columns")}),(0,h.tZ)("div",{className:"field-selections"},e.type===Xe.i9.Query&&"false"!==sessionStorage.getItem("showInfobox")&&(0,h.tZ)(gt,null,(0,h.tZ)(Le.Z,{closable:!0,onClose:()=>sessionStorage.setItem("showInfobox","false"),type:"info",message:"",description:(0,h.tZ)(o.Fragment,null,(0,h.tZ)("span",{role:"button",tabIndex:0,onClick:()=>d(!0),className:"add-dataset-alert-description"},(0,n.t)("Create a dataset")),(0,n.t)(" to edit or add columns and metrics."))})),(0,h.tZ)($e.Z,{defaultActiveKey:["metrics","column"],expandIconPosition:"right",ghost:!0},(0,h.tZ)($e.Z.Panel,{header:(0,h.tZ)(mt,null,(0,n.t)("Metrics")),key:"metrics"},(0,h.tZ)("div",{className:"field-length"},(0,n.t)("Showing %s of %s",x.length,g.metrics.length)),x.map((e=>(0,h.tZ)(ft,{key:e.metric_name+String(r),className:"column"},ct?(0,h.tZ)(lt,{value:e,type:nt.g.Metric}):(0,h.tZ)(st.B,{metric:e,showType:!0})))),g.metrics.length>50?(0,h.tZ)(ut,null,(0,h.tZ)(dt,{onClick:()=>y(!v)},v?(0,n.t)("Show less..."):(0,n.t)("Show all..."))):(0,h.tZ)(o.Fragment,null)),(0,h.tZ)($e.Z.Panel,{header:(0,h.tZ)(mt,null,(0,n.t)("Columns")),key:"column"},(0,h.tZ)("div",{className:"field-length"},(0,n.t)("Showing %s of %s",Z.length,g.columns.length)),Z.map((e=>(0,h.tZ)(ft,{key:e.column_name+String(r),className:"column"},ct?(0,h.tZ)(lt,{value:e,type:nt.g.Column}):(0,h.tZ)(st.l,{column:e,showType:!0})))),g.columns.length>50?(0,h.tZ)(ut,null,(0,h.tZ)(dt,{onClick:()=>w(!S)},S?(0,n.t)("Show Less..."):(0,n.t)("Show all..."))):(0,h.tZ)(o.Fragment,null)))))),[Z,u,g.columns.length,g.metrics.length,x,_,S,v,r]);return(0,h.tZ)(ht,null,(0,h.tZ)(tt.W,{visible:c,onHide:()=>d(!1),buttonTextOnSave:(0,n.t)("Save"),buttonTextOnOverwrite:(0,n.t)("Overwrite"),datasource:e}),(0,h.tZ)(Ee.Z,m()({},t,{name:"datasource",actions:a})),null!=e.id&&k)}var bt=a(28062),yt=a(61358),St=a(41609),wt=a.n(St),_t=a(18446),xt=a.n(_t),Zt=a(88306),kt=a.n(Zt),Ct=a(38575),Tt=a(92252);const Nt=kt()(((e,t)=>{const a={};return((null==t?void 0:t.controlPanelSections)||[]).filter(Ct.D_).forEach((e=>{e.controlSetRows.forEach((e=>{e.forEach((e=>{e&&("string"==typeof e?a[e]=Tt.ai[e]:e.name&&e.config&&(a[e.name]=e.config))}))}))})),a}));var $t=a(9679),It=a(68073),Dt=a(76962);const Rt={origFormData:S().object.isRequired,currentFormData:S().object.isRequired},Et=_.iK.span`
  ${({theme:e})=>`\n    font-size: ${e.typography.sizes.s}px;\n    color: ${e.colors.grayscale.dark1};\n    background-color: ${e.colors.alert.base};\n\n    &: hover {\n      background-color: ${e.colors.alert.dark1};\n    }\n  `}
`;function At(e){if(null==e||""===e)return null;if("object"==typeof e){if(Array.isArray(e)&&0===e.length)return null;const t=Object.keys(e);if(t&&0===t.length)return null}return e}class Ot extends o.Component{constructor(e){super(e);const t=this.getDiffs(e),a=(e=>{const t=(0,Ce.Z)().get(e);return Nt(e,t)})(this.props.origFormData.viz_type),o=this.getRowsFromDiffs(t,a);this.state={rows:o,hasDiffs:!wt()(t),controlsMap:a}}UNSAFE_componentWillReceiveProps(e){if(xt()(this.props,e))return;const t=this.getDiffs(e);this.setState((e=>({rows:this.getRowsFromDiffs(t,e.controlsMap),hasDiffs:!wt()(t)})))}getRowsFromDiffs(e,t){return Object.entries(e).map((([e,a])=>({control:t[e]&&t[e].label||e,before:this.formatValue(a.before,e,t),after:this.formatValue(a.after,e,t)})))}getDiffs(e){const t=(0,Q.BR)(e.origFormData),a=(0,Q.BR)(e.currentFormData),o=Object.keys(a),r={};return o.forEach((e=>{(t[e]||a[e])&&(["filters","having","having_filters","where"].includes(e)||this.isEqualish(t[e],a[e])||(r[e]={before:t[e],after:a[e]}))})),r}isEqualish(e,t){return xt()(At(e),At(t))}formatValue(e,t,a){var o,r,n,s;if(void 0===e)return"N/A";if(null===e)return"null";if("AdhocFilterControl"===(null==(o=a[t])?void 0:o.type))return e.length?e.map((e=>{const t=e.comparator&&e.comparator.constructor===Array?`[${e.comparator.join(", ")}]`:e.comparator;return`${e.subject} ${e.operator} ${t}`})).join(", "):"[]";if("BoundsControl"===(null==(r=a[t])?void 0:r.type))return`Min: ${e[0]}, Max: ${e[1]}`;if("CollectionControl"===(null==(n=a[t])?void 0:n.type))return e.map((e=>(0,$t.o)(e))).join(", ");if("MetricsControl"===(null==(s=a[t])?void 0:s.type)&&e.constructor===Array){const t=e.map((e=>{var t;return null!=(t=null==e?void 0:e.label)?t:e}));return t.length?t.join(", "):"[]"}if("boolean"==typeof e)return e?"true":"false";if(e.constructor===Array){const t=e.map((e=>{var t;return null!=(t=null==e?void 0:e.label)?t:e}));return t.length?t.join(", "):"[]"}return"string"==typeof e||"number"==typeof e?e:(0,$t.o)(e)}renderModalBody(){return(0,h.tZ)(Dt.Z,{columns:[{accessor:"control",Header:"Control"},{accessor:"before",Header:"Before"},{accessor:"after",Header:"After"}],data:this.state.rows,pageSize:50,className:"table-condensed",columnsForWrapText:["Control","Before","After"]})}renderTriggerNode(){return(0,h.tZ)(T.u,{id:"difference-tooltip",title:(0,n.t)("Click to see difference")},(0,h.tZ)(Et,{className:"label"},(0,n.t)("Altered")))}render(){return this.state.hasDiffs?(0,h.tZ)(It.Z,{triggerNode:this.renderTriggerNode(),modalTitle:(0,n.t)("Chart changes"),modalBody:this.renderModalBody(),responsive:!0}):null}}Ot.propTypes=Rt;var Ut=a(83673),zt=a(52564),Mt=a(94413);const jt={actions:S().object.isRequired,canOverwrite:S().bool.isRequired,canDownload:S().bool.isRequired,dashboardId:S().number,isStarred:S().bool.isRequired,slice:S().object,sliceName:S().string,table_name:S().string,formData:S().object,ownState:S().object,timeout:S().number,chart:q.$6,saveDisabled:S().bool},Ft=e=>h.iv`
  color: ${e.colors.primary.dark2};
  & > span[role='img'] {
    margin-right: 0;
  }
`,qt=({dashboardId:e,slice:t,actions:a,formData:r,ownState:s,chart:i,user:l,canOverwrite:c,canDownload:d,isStarred:u,sliceUpdated:p,sliceName:m,onSaveChart:g,saveDisabled:f})=>{const{latestQueryFormData:v,sliceFormData:b}=i,[y,S]=(0,o.useState)(!1);(0,o.useEffect)((()=>{e&&(async()=>{await G.Z.get({endpoint:`/api/v1/chart/${t.slice_id}`}).then((t=>{var a;const o=null==t||null==(a=t.json)?void 0:a.result;if(o&&o.dashboards&&o.dashboards.length){const{dashboards:t}=o,a=e&&t.length&&t.find((t=>t.id===e));if(a&&a.json_metadata){const e=JSON.parse(a.json_metadata),t={...e.shared_label_colors||{},...e.label_colors||{}},o=bt.getNamespace();Object.keys(t).forEach((a=>{o.setColor(a,t[a],e.color_scheme)}))}}})).catch((()=>{}))})()}),[]);const[w,_,x]=(0,Mt.gT)(v,d,t,a.redirectSQLLab,(()=>{S(!0)}),s),Z=null==t?void 0:t.slice_name;return(0,h.tZ)(o.Fragment,null,(0,h.tZ)(zt.u,{editableTitleProps:{title:m,canEdit:!t||c||((null==t?void 0:t.owners)||[]).includes(null==l?void 0:l.userId),onSave:a.updateChartTitle,placeholder:(0,n.t)("Add the name of the chart"),label:(0,n.t)("Chart title")},showTitlePanelItems:!!t,certificatiedBadgeProps:{certifiedBy:null==t?void 0:t.certified_by,details:null==t?void 0:t.certification_details},showFaveStar:!(null==l||!l.userId),faveStarProps:{itemId:null==t?void 0:t.slice_id,fetchFaveStar:a.fetchFaveStar,saveFaveStar:a.saveFaveStar,isStarred:u,showTooltip:!0},titlePanelAdditionalItems:b?(0,h.tZ)(Ot,{className:"altered",origFormData:{...b,chartTitle:Z},currentFormData:{...r,chartTitle:m}}):null,rightPanelAdditionalItems:(0,h.tZ)(T.u,{title:f?(0,n.t)("Add required control values to save chart"):null},(0,h.tZ)("div",null,(0,h.tZ)(pe.Z,{buttonStyle:"secondary",onClick:g,disabled:f,css:Ft},(0,h.tZ)(I.Z.SaveOutlined,{iconSize:"l"}),(0,n.t)("Save")))),additionalActionsMenu:w,menuDropdownProps:{visible:_,onVisibleChange:x}}),y&&(0,h.tZ)(Ut.Z,{show:y,onHide:()=>{S(!1)},onSave:p,slice:t}))};qt.propTypes=jt;const Lt=(0,r.$j)(null,(function(e){return(0,w.DE)({sliceUpdated:H.sliceUpdated,toggleActive:yt.M,deleteActiveReport:yt.MZ},e)}))(qt),Qt={...ke.propTypes,actions:S().object.isRequired,datasource_type:S().string.isRequired,dashboardId:S().number,isDatasourceMetaLoading:S().bool.isRequired,chart:q.$6.isRequired,slice:S().object,sliceName:S().string,controls:S().object.isRequired,forcedHeight:S().string,form_data:S().object.isRequired,standalone:S().number.isRequired,force:S().bool,timeout:S().number,impressionId:S().string,vizType:S().string},Pt=_.iK.div`
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
`,Kt=_.iK.div`
  ${({theme:e})=>h.iv`
    background: ${e.colors.grayscale.light5};
    text-align: left;
    position: relative;
    width: 100%;
    max-height: 100%;
    min-height: 0;
    display: flex;
    flex: 1;
    flex-wrap: nowrap;
    border-top: 1px solid ${e.colors.grayscale.light2};
    .explore-column {
      display: flex;
      flex-direction: column;
      padding: ${2*e.gridUnit}px 0;
      max-height: 100%;
    }
    .data-source-selection {
      background-color: ${e.colors.grayscale.light5};
      padding: ${2*e.gridUnit}px 0;
      border-right: 1px solid ${e.colors.grayscale.light2};
    }
    .main-explore-content {
      flex: 1;
      min-width: ${128*e.gridUnit}px;
      border-left: 1px solid ${e.colors.grayscale.light2};
      padding: 0 ${4*e.gridUnit}px;
      .panel {
        margin-bottom: 0;
      }
    }
    .controls-column {
      align-self: flex-start;
      padding: 0;
    }
    .title-container {
      position: relative;
      display: flex;
      flex-direction: row;
      padding: 0 ${4*e.gridUnit}px;
      justify-content: space-between;
      .horizontal-text {
        font-size: ${e.typography.sizes.s}px;
      }
    }
    .no-show {
      display: none;
    }
    .vertical-text {
      writing-mode: vertical-rl;
      text-orientation: mixed;
    }
    .sidebar {
      height: 100%;
      background-color: ${e.colors.grayscale.light4};
      padding: ${2*e.gridUnit}px;
      width: ${8*e.gridUnit}px;
    }
    .callpase-icon > svg {
      color: ${e.colors.primary.base};
    }
  `};
`,Bt=b()((async(e,t,a,o,r,n,s,i)=>{const l={...e},c=e.slice_id,d={};c?d[R.KD.sliceId.name]=c:(d[R.KD.datasourceId.name]=t,d[R.KD.datasourceType.name]=a);const u=(null==l?void 0:l.url_params)||{};Object.entries(u).forEach((([e,t])=>{R.$O.includes(e)||(d[e]=t)}));try{let u,h;o?(u=await(0,Q.nv)(t,a,e,c,i),h="replaceState"):(u=(0,U.eY)(R.KD.formDataKey),await(0,Q.LW)(t,a,u,e,c,i),h="pushState");const p=(0,K.y8)(r?R.KD.standalone.name:null,{[R.KD.formDataKey.name]:u,...d},n);window.history[h](l,s,p)}catch(e){x.Z.warn("Failed at altering browser history",e)}}),1e3);function Ht(e){const t=(0,C.gp)().dynamicPlugins[e.vizType],a=t&&t.mounting,r=(0,N.D)(a),s=(0,N.D)(e.controls),[i,l]=(0,o.useState)(e.controls),[c,d]=(0,o.useState)(!1),[u,p]=(0,o.useState)(!1),[g,v]=(0,o.useState)(-1),b=(0,W.z)(),y=(0,_.Fg)(),S={controls_width:320,datasource_width:300},w=(0,o.useCallback)((async({isReplace:t=!1,title:a}={})=>{const o=e.dashboardId?{...e.form_data,dashboardId:e.dashboardId}:e.form_data,{id:r,type:n}=e.datasource;Bt(o,r,n,t,e.standalone,e.force,a,b)}),[e.dashboardId,e.form_data,e.datasource.id,e.datasource.type,e.standalone,e.force,b]),x=(0,o.useCallback)((()=>{const t=window.history.state;t&&Object.keys(t).length&&(e.actions.setExploreControls(t),e.actions.postChartFormData(t,e.force,e.timeout,e.chart.id))}),[e.actions,e.chart.id,e.timeout]),R=(0,o.useCallback)((()=>{e.actions.setForceQuery(!1),e.actions.triggerQuery(!0,e.chart.id),w(),l(e.controls)}),[e.controls,w,e.actions,e.chart.id]),A=(0,o.useCallback)((t=>{if(t.ctrlKey||t.metaKey){const a="Enter"===t.key||13===t.keyCode,o="s"===t.key||83===t.keyCode;a?R():o&&e.slice&&e.actions.saveSlice(e.form_data,{action:"overwrite",slice_id:e.slice.slice_id,slice_name:e.slice.slice_name,add_to_dash:"noSave",goto_dash:!1}).then((({data:e})=>{window.location=e.slice.slice_url}))}}),[R,e.actions,e.form_data,e.slice]);function U(){d(!c)}function z(){p(!u)}(0,$.J)((()=>{e.actions.logEvent(O.$b)})),(0,k.S)(b,((e,t)=>{t&&w({isReplace:!0})}));const j=(0,N.D)(x);(0,o.useEffect)((()=>(j&&window.removeEventListener("popstate",j),window.addEventListener("popstate",x),()=>{window.removeEventListener("popstate",x)})),[x,j]);const q=(0,N.D)(A);(0,o.useEffect)((()=>(q&&window.removeEventListener("keydown",q),document.addEventListener("keydown",A),()=>{document.removeEventListener("keydown",A)})),[A,q]),(0,o.useEffect)((()=>{r&&!a&&e.actions.dynamicPluginControlsReady()}),[a]),(0,o.useEffect)((()=>{Object.values(e.controls).some((e=>e.validationErrors&&e.validationErrors.length>0))||e.actions.triggerQuery(!0,e.chart.id)}),[]);const L=(0,o.useCallback)((t=>{const a=t?{...e.chart.latestQueryFormData,...(0,B.Hu)(f()(e.controls,t))}:(0,B.Hu)(e.controls);e.actions.updateQueryFormData(a,e.chart.id),e.actions.renderTriggered((new Date).getTime(),e.chart.id),w()}),[w,e.actions,e.chart.id,e.chart.latestQueryFormData,e.controls]);(0,o.useEffect)((()=>{if(s&&e.chart.latestQueryFormData.viz_type===e.controls.viz_type.value){!e.controls.datasource||null!=s.datasource&&e.controls.datasource.value===s.datasource.value||(0,F.QR)(e.form_data.datasource,!0);const t=Object.keys(e.controls).filter((t=>void 0!==s[t]&&!(0,E.JB)(e.controls[t].value,s[t].value))).filter((t=>e.controls[t].renderTrigger));t.length>0&&L(t)}}),[e.controls,e.ownState]);const Q=(0,o.useMemo)((()=>!!i&&Object.keys(e.controls).filter((t=>void 0!==i[t]&&!(0,E.JB)(e.controls[t].value,i[t].value))).some((t=>!e.controls[t].renderTrigger&&!e.controls[t].dontRefreshOnChange))),[i,e.controls]);(0,o.useEffect)((()=>{void 0!==e.ownState&&(R(),L())}),[e.ownState]),Q&&e.actions.logEvent(O.Ep);const P=(0,o.useMemo)((()=>{const t=Object.values(e.controls).filter((e=>e.validationErrors&&e.validationErrors.length>0));if(0===t.length)return null;const a=t.map((e=>e.validationErrors)),o=[...new Set(a.flat())].map((e=>[t.filter((t=>{var a;return null==(a=t.validationErrors)?void 0:a.includes(e)})).map((e=>e.label)),e])).map((([e,t])=>(0,h.tZ)("div",{key:t},e.length>1?(0,n.t)("Controls labeled "):(0,n.t)("Control labeled "),(0,h.tZ)("strong",null,` ${e.join(", ")}`),(0,h.tZ)("span",null,": ",t))));let r;return o.length>0&&(r=(0,h.tZ)("div",{style:{textAlign:"left"}},o)),r}),[e.controls]);function K(){return(0,h.tZ)(ke,m()({},e,{errorMessage:P,chartIsStale:Q,onQuery:R}))}function H(e){return(0,D.rV)(e,S[e])}function V(e,t){const a=Number(H(e))+t.width;(0,D.LS)(e,a)}return e.standalone?K():(0,h.tZ)(Pt,null,(0,h.tZ)(Lt,{actions:e.actions,canOverwrite:e.can_overwrite,canDownload:e.can_download,dashboardId:e.dashboardId,isStarred:e.isStarred,slice:e.slice,sliceName:e.sliceName,table_name:e.table_name,formData:e.form_data,chart:e.chart,ownState:e.ownState,user:e.user,reports:e.reports,onSaveChart:U,saveDisabled:P||"loading"===e.chart.chartStatus}),(0,h.tZ)(Kt,{id:"explore-container"},(0,h.tZ)(h.xB,{styles:h.iv`
            .navbar {
              margin-bottom: 0;
            }
            body {
              height: 100vh;
              max-height: 100vh;
              overflow: hidden;
            }
            #app-menu,
            #app {
              flex: 1 1 auto;
            }
            #app {
              flex-basis: 100%;
              overflow: hidden;
              height: 100%;
            }
            #app-menu {
              flex-shrink: 0;
            }
          `}),c&&(0,h.tZ)(Ge,{onHide:U,actions:e.actions,form_data:e.form_data,sliceName:e.sliceName,dashboardId:e.dashboardId}),(0,h.tZ)(Z.e,{onResizeStop:(e,t,a,o)=>{v(null==o?void 0:o.width),V(D.dR.datasource_width,o)},defaultSize:{width:H(D.dR.datasource_width),height:"100%"},minWidth:S[D.dR.datasource_width],maxWidth:"33%",enable:{right:!0},className:u?"no-show":"explore-column data-source-selection"},(0,h.tZ)("div",{className:"title-container"},(0,h.tZ)("span",{className:"horizontal-text"},(0,n.t)("Dataset")),(0,h.tZ)("span",{role:"button",tabIndex:0,className:"action-button",onClick:z},(0,h.tZ)(I.Z.Expand,{className:"collapse-icon",iconColor:y.colors.primary.base,iconSize:"l"}))),(0,h.tZ)(vt,{datasource:e.datasource,controls:e.controls,actions:e.actions,shouldForceUpdate:g,user:e.user})),u?(0,h.tZ)("div",{className:"sidebar",onClick:z,role:"button",tabIndex:0},(0,h.tZ)("span",{role:"button",tabIndex:0,className:"action-button"},(0,h.tZ)(T.u,{title:(0,n.t)("Open Datasource tab")},(0,h.tZ)(I.Z.Collapse,{className:"collapse-icon",iconColor:y.colors.primary.base,iconSize:"l"}))),(0,h.tZ)(I.Z.DatasetPhysical,{css:(0,h.iv)({marginTop:2*y.gridUnit},"",""),iconSize:"l",iconColor:y.colors.grayscale.base})):null,(0,h.tZ)(Z.e,{onResizeStop:(e,t,a,o)=>V(D.dR.controls_width,o),defaultSize:{width:H(D.dR.controls_width),height:"100%"},minWidth:S[D.dR.controls_width],maxWidth:"33%",enable:{right:!0},className:"col-sm-3 explore-column controls-column"},(0,h.tZ)(je,{exploreState:e.exploreState,actions:e.actions,form_data:e.form_data,controls:e.controls,chart:e.chart,datasource_type:e.datasource_type,isDatasourceMetaLoading:e.isDatasourceMetaLoading,onQuery:R,onStop:function(){e.chart&&e.chart.queryController&&e.chart.queryController.abort()},canStopQuery:e.can_add||e.can_overwrite,errorMessage:P,chartIsStale:Q})),(0,h.tZ)("div",{className:M()("main-explore-content",u?"col-sm-9":"col-sm-7")},K())))}Ht.propTypes=Qt;const Vt=(0,r.$j)((function(e){var t,a,o,r,n,s,i,l;const{explore:c,charts:d,common:u,impressionId:h,dataMask:p,reports:m,user:g}=e,{controls:f,slice:v,datasource:b}=c,y=(0,B.Hu)(f),S=null!=(t=null!=(a=y.slice_id)?a:null==v?void 0:v.slice_id)?t:0;y.extra_form_data=(0,L.on)({...y.extra_form_data},{...null==(o=p[S])?void 0:o.ownState});const w=d[S];let _=Number(null==(r=c.form_data)?void 0:r.dashboardId);return Number.isNaN(_)&&(_=void 0),{isDatasourceMetaLoading:c.isDatasourceMetaLoading,datasource:b,datasource_type:b.type,datasourceId:b.datasource_id,dashboardId:_,controls:c.controls,can_add:!!c.can_add,can_download:!!c.can_download,can_overwrite:!!c.can_overwrite,column_formats:null!=(n=null==b?void 0:b.column_formats)?n:null,containerId:v?`slice-container-${v.slice_id}`:"slice-container",isStarred:c.isStarred,slice:v,sliceName:null!=(s=null!=(i=c.sliceName)?i:null==v?void 0:v.slice_name)?s:null,triggerRender:c.triggerRender,form_data:y,table_name:b.table_name,vizType:y.viz_type,standalone:!!c.standalone,force:!!c.force,chart:w,timeout:u.conf.SUPERSET_WEBSERVER_TIMEOUT,ownState:null==(l=p[S])?void 0:l.ownState,impressionId:h,user:g,exploreState:c,reports:m}}),(function(e){const t={...H,...P.yn,...V,...j,...A};return{actions:(0,w.DE)(t,e)}}))(Ht);a(65634);(0,n.t)("Chart Options"),(0,n.t)("Use Area Proportions"),(0,n.t)("Check if the Rose Chart should use segment area instead of segment radius for proportioning"),(0,n.t)("Stacked Style"),(0,n.t)("Chart Options"),(0,n.t)("Chart Options"),(0,n.t)("Columns"),(0,n.t)("Columns to display"),Xe.i9.Table;const Wt={form_data:{datasource:"0__table",viz_type:"table"},dataset:{id:0,type:Xe.i9.Table,columns:[],metrics:[],column_format:{},verbose_map:{},main_dttm_col:"",owners:[],datasource_name:"missing_datasource",name:"missing_datasource",description:null},slice:null};var Jt=a(72570),Yt=a(54076);const Gt=(0,n.t)("Failed to load chart data."),Xt=()=>{const[e,t]=(0,o.useState)(!1),a=(0,r.I0)();return(0,o.useEffect)((()=>{(()=>{const e=new URLSearchParams(Object.entries({...d(),...Object.keys(c).reduce(((e,t)=>{const a=new RegExp(`/(${t})/(\\w+)`),o=window.location.pathname.match(a);return o&&o[2]?{...e,[c[t]]:o[2]}:e}),{})}).map((e=>e.join("="))).join("&"));return(0,s.Z)({method:"GET",endpoint:"api/v1/explore/"})(e)})().then((({result:e})=>{var t,o;(0,Yt.Rw)(null==(t=e.dataset)?void 0:t.id)&&(0,Yt.Rw)(null==(o=e.dataset)?void 0:o.uid)?(a((0,u.u)(Wt)),a((0,Jt.Gb)(Gt))):a((0,u.u)(e))})).catch((()=>{a((0,u.u)(Wt)),a((0,Jt.Gb)(Gt))})).finally((()=>{t(!0)}))}),[a]),e?(0,h.tZ)(Vt,null):(0,h.tZ)(i.Z,null)}},54804:(e,t,a)=>{"use strict";a.d(t,{hb:()=>i,QU:()=>l,Es:()=>c,JL:()=>d});var o=a(42190),r=a(15926);function n({owners:e}){return e?e.map((e=>`${e.first_name} ${e.last_name}`)):null}const s=a.n(r)().encode({columns:["owners.first_name","owners.last_name"],keys:["none"]});function i(e){return(0,o.l6)((0,o.s_)(`/api/v1/chart/${e}?q=${s}`),n)}const l=e=>(0,o.l6)((0,o.s_)(`/api/v1/dashboard/${e}`),(e=>({...e,metadata:e.json_metadata&&JSON.parse(e.json_metadata)||{},position_data:e.position_json&&JSON.parse(e.position_json)}))),c=e=>(0,o.s_)(`/api/v1/dashboard/${e}/charts`),d=e=>(0,o.s_)(`/api/v1/dashboard/${e}/datasets`)}}]);
//# sourceMappingURL=4460a6513f7de8e96bc7.chunk.js.map