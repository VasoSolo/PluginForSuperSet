(globalThis.webpackChunksuperset=globalThis.webpackChunksuperset||[]).push([[665],{45578:(e,t,a)=>{var l=a(67206),r=a(45652);e.exports=function(e,t){return e&&e.length?r(e,l(t,2)):[]}},27989:(e,t,a)=>{"use strict";a.d(t,{Z:()=>h});var l=a(67294),r=a(51995),i=a(61988),o=a(35932),s=a(74069),n=a(26506),d=a(34858),c=a(60972),u=a(11965);const p=r.iK.div`
  display: block;
  color: ${({theme:e})=>e.colors.grayscale.base};
  font-size: ${({theme:e})=>e.typography.sizes.s}px;
`,m=r.iK.div`
  padding-bottom: ${({theme:e})=>2*e.gridUnit}px;
  padding-top: ${({theme:e})=>2*e.gridUnit}px;

  & > div {
    margin: ${({theme:e})=>e.gridUnit}px 0;
  }

  &.extra-container {
    padding-top: 8px;
  }

  .confirm-overwrite {
    margin-bottom: ${({theme:e})=>2*e.gridUnit}px;
  }

  .input-container {
    display: flex;
    align-items: center;

    label {
      display: flex;
      margin-right: ${({theme:e})=>2*e.gridUnit}px;
    }

    i {
      margin: 0 ${({theme:e})=>e.gridUnit}px;
    }
  }

  input,
  textarea {
    flex: 1 1 auto;
  }

  textarea {
    height: 160px;
    resize: none;
  }

  input::placeholder,
  textarea::placeholder {
    color: ${({theme:e})=>e.colors.grayscale.light1};
  }

  textarea,
  input[type='text'],
  input[type='number'] {
    padding: ${({theme:e})=>1.5*e.gridUnit}px
      ${({theme:e})=>2*e.gridUnit}px;
    border-style: none;
    border: 1px solid ${({theme:e})=>e.colors.grayscale.light2};
    border-radius: ${({theme:e})=>e.gridUnit}px;

    &[name='name'] {
      flex: 0 1 auto;
      width: 40%;
    }

    &[name='sqlalchemy_uri'] {
      margin-right: ${({theme:e})=>3*e.gridUnit}px;
    }
  }
`,h=({resourceName:e,resourceLabel:t,passwordsNeededMessage:a,confirmOverwriteMessage:r,onModelImport:h,show:g,onHide:b,passwordFields:y=[],setPasswordFields:f=(()=>{})})=>{const[v,Z]=(0,l.useState)(!0),[w,_]=(0,l.useState)({}),[x,S]=(0,l.useState)(!1),[C,E]=(0,l.useState)(!1),[T,k]=(0,l.useState)([]),[$,N]=(0,l.useState)(!1),[I,H]=(0,l.useState)(),A=()=>{k([]),f([]),_({}),S(!1),E(!1),N(!1),H("")},{state:{alreadyExists:F,passwordsNeeded:M},importResource:z}=(0,d.PW)(e,t,(e=>{H(e)}));(0,l.useEffect)((()=>{f(M),M.length>0&&N(!1)}),[M,f]),(0,l.useEffect)((()=>{S(F.length>0),F.length>0&&N(!1)}),[F,S]);return v&&g&&Z(!1),(0,u.tZ)(s.Z,{name:"model",className:"import-model-modal",disablePrimaryButton:0===T.length||x&&!C||$,onHandledPrimaryAction:()=>{var e;(null==(e=T[0])?void 0:e.originFileObj)instanceof File&&(N(!0),z(T[0].originFileObj,w,C).then((e=>{e&&(A(),h())})))},onHide:()=>{Z(!0),b(),A()},primaryButtonName:x?(0,i.t)("Overwrite"):(0,i.t)("Import"),primaryButtonType:x?"danger":"primary",width:"750px",show:g,title:(0,u.tZ)("h4",null,(0,i.t)("Import %s",t))},(0,u.tZ)(m,null,(0,u.tZ)(n.gq,{name:"modelFile",id:"modelFile",accept:".yaml,.json,.yml,.zip",fileList:T,onChange:e=>{k([{...e.file,status:"done"}])},onRemove:e=>(k(T.filter((t=>t.uid!==e.uid))),!1),customRequest:()=>{},disabled:$},(0,u.tZ)(o.Z,{loading:$},"Select file"))),I&&(0,u.tZ)(c.Z,{errorMessage:I,showDbInstallInstructions:y.length>0}),0===y.length?null:(0,u.tZ)(l.Fragment,null,(0,u.tZ)("h5",null,"Database passwords"),(0,u.tZ)(p,null,a),y.map((e=>(0,u.tZ)(m,{key:`password-for-${e}`},(0,u.tZ)("div",{className:"control-label"},e,(0,u.tZ)("span",{className:"required"},"*")),(0,u.tZ)("input",{name:`password-${e}`,autoComplete:`password-${e}`,type:"password",value:w[e],onChange:t=>_({...w,[e]:t.target.value})}))))),x?(0,u.tZ)(l.Fragment,null,(0,u.tZ)(m,null,(0,u.tZ)("div",{className:"confirm-overwrite"},r),(0,u.tZ)("div",{className:"control-label"},(0,i.t)('Type "%s" to confirm',(0,i.t)("OVERWRITE"))),(0,u.tZ)("input",{id:"overwrite",type:"text",onChange:e=>{var t,a;const l=null!=(t=null==(a=e.currentTarget)?void 0:a.value)?t:"";E(l.toUpperCase()===(0,i.t)("OVERWRITE"))}}))):null)}},13434:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>P});var l=a(45578),r=a.n(l),i=a(51995),o=a(61988),s=a(11064),n=a(31069),d=a(67294),c=a(15926),u=a.n(c),p=a(30381),m=a.n(p),h=a(91877),g=a(93185),b=a(40768),y=a(34858),f=a(32228),v=a(19259),Z=a(20755),w=a(36674),_=a(73727),x=a(18782),S=a(38703),C=a(61337),E=a(14114),T=a(83673),k=a(27989),$=a(58593),N=a(70163),I=a(1510),H=a(2120),A=a(8272),F=a(79789),M=a(34024),z=a(11965);const D=i.iK.div`
  align-items: center;
  display: flex;

  a {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    line-height: 1.2;
  }

  svg {
    margin-right: ${({theme:e})=>e.gridUnit}px;
  }
`,U=(0,o.t)('The passwords for the databases below are needed in order to import them together with the charts. Please note that the "Secure Extra" and "Certificate" sections of the database configuration are not present in export files, and should be added manually after the import if they are needed.'),B=(0,o.t)("You are importing one or more charts that already exist. Overwriting might cause you to lose some of your work. Are you sure you want to overwrite?");(0,H.Z)();const O=(0,s.Z)(),L=async(e="",t,a)=>{var l;const i=e?{filters:[{col:"table_name",opr:"sw",value:e}]}:{},o=u().encode({columns:["datasource_name","datasource_id"],keys:["none"],order_column:"table_name",order_direction:"asc",page:t,page_size:a,...i}),{json:s={}}=await n.Z.get({endpoint:`/api/v1/dataset/?q=${o}`}),d=null==s||null==(l=s.result)?void 0:l.map((({table_name:e,id:t})=>({label:e,value:t})));return{data:r()(d,"value"),totalCount:null==s?void 0:s.count}},R=i.iK.div`
  color: ${({theme:e})=>e.colors.grayscale.base};
`,P=(0,E.ZP)((function(e){const{addDangerToast:t,addSuccessToast:a,user:{userId:l}}=e,{state:{loading:r,resourceCount:i,resourceCollection:s,bulkSelectEnabled:c},setResourceCollection:p,hasPerm:E,fetchData:H,toggleBulkSelect:P,refreshData:q}=(0,y.Yi)("chart",(0,o.t)("chart"),t),V=(0,d.useMemo)((()=>s.map((e=>e.id))),[s]),[j,W]=(0,y.NE)("chart",V,t),{sliceCurrentlyEditing:K,handleChartUpdated:Y,openChartEditModal:X,closeChartEditModal:G}=(0,y.fF)(p,s),[J,Q]=(0,d.useState)(!1),[ee,te]=(0,d.useState)([]),[ae,le]=(0,d.useState)(!1),re=(0,C.OH)(null==l?void 0:l.toString(),null),ie=E("can_write"),oe=E("can_write"),se=E("can_write"),ne=E("can_export")&&(0,h.cr)(g.T.VERSIONED_EXPORT),de=[{id:"changed_on_delta_humanized",desc:!0}],ce=e=>{const t=e.map((({id:e})=>e));(0,f.Z)("chart",t,(()=>{le(!1)})),le(!0)},ue=(0,d.useMemo)((()=>[{Cell:({row:{original:{id:e}}})=>l&&(0,z.tZ)(w.Z,{itemId:e,saveFaveStar:j,isStarred:W[e]}),Header:"",id:"id",disableSortBy:!0,size:"xs",hidden:!l},{Cell:({row:{original:{url:e,slice_name:t,certified_by:a,certification_details:l,description:r}}})=>(0,z.tZ)(D,null,(0,z.tZ)(_.rU,{to:e},a&&(0,z.tZ)(d.Fragment,null,(0,z.tZ)(F.Z,{certifiedBy:a,details:l})," "),t),r&&(0,z.tZ)(A.Z,{tooltip:r,viewBox:"0 -1 24 24"})),Header:(0,o.t)("Chart"),accessor:"slice_name"},{Cell:({row:{original:{viz_type:e}}})=>{var t;return(null==(t=O.get(e))?void 0:t.name)||e},Header:(0,o.t)("Visualization type"),accessor:"viz_type",size:"xxl"},{Cell:({row:{original:{datasource_name_text:e,datasource_url:t}}})=>(0,z.tZ)("a",{href:t},e),Header:(0,o.t)("Dataset"),accessor:"datasource_id",disableSortBy:!0,size:"xl"},{Cell:({row:{original:{last_saved_by:e,changed_by_url:t}}})=>(0,z.tZ)("a",{href:t},null!=e&&e.first_name?`${null==e?void 0:e.first_name} ${null==e?void 0:e.last_name}`:null),Header:(0,o.t)("Modified by"),accessor:"last_saved_by.first_name",size:"xl"},{Cell:({row:{original:{last_saved_at:e}}})=>(0,z.tZ)("span",{className:"no-wrap"},e?m().utc(e).fromNow():null),Header:(0,o.t)("Last modified"),accessor:"last_saved_at",size:"xl"},{accessor:"owners",hidden:!0,disableSortBy:!0},{Cell:({row:{original:{created_by:e}}})=>e?`${e.first_name} ${e.last_name}`:"",Header:(0,o.t)("Created by"),accessor:"created_by",disableSortBy:!0,size:"xl"},{Cell:({row:{original:e}})=>oe||se||ne?(0,z.tZ)(R,{className:"actions"},se&&(0,z.tZ)(v.Z,{title:(0,o.t)("Please confirm"),description:(0,z.tZ)(d.Fragment,null,(0,o.t)("Are you sure you want to delete")," ",(0,z.tZ)("b",null,e.slice_name),"?"),onConfirm:()=>(0,b.Gm)(e,a,t,q)},(e=>(0,z.tZ)($.u,{id:"delete-action-tooltip",title:(0,o.t)("Delete"),placement:"bottom"},(0,z.tZ)("span",{role:"button",tabIndex:0,className:"action-button",onClick:e},(0,z.tZ)(N.Z.Trash,null))))),ne&&(0,z.tZ)($.u,{id:"export-action-tooltip",title:(0,o.t)("Export"),placement:"bottom"},(0,z.tZ)("span",{role:"button",tabIndex:0,className:"action-button",onClick:()=>ce([e])},(0,z.tZ)(N.Z.Share,null))),oe&&(0,z.tZ)($.u,{id:"edit-action-tooltip",title:(0,o.t)("Edit"),placement:"bottom"},(0,z.tZ)("span",{role:"button",tabIndex:0,className:"action-button",onClick:()=>X(e)},(0,z.tZ)(N.Z.EditAlt,null)))):null,Header:(0,o.t)("Actions"),id:"actions",disableSortBy:!0,hidden:!oe&&!se}]),[l,oe,se,ne,j,W,q,a,t]),pe=(0,d.useMemo)((()=>({Header:(0,o.t)("Favorite"),id:"id",urlDisplay:"favorite",input:"select",operator:x.p.chartIsFav,unfilteredLabel:(0,o.t)("Any"),selects:[{label:(0,o.t)("Yes"),value:!0},{label:(0,o.t)("No"),value:!1}]})),[]),me=(0,d.useMemo)((()=>[{Header:(0,o.t)("Owner"),id:"owners",input:"select",operator:x.p.relationManyMany,unfilteredLabel:(0,o.t)("All"),fetchSelects:(0,b.tm)("chart","owners",(0,b.v$)((e=>t((0,o.t)("An error occurred while fetching chart owners values: %s",e)))),e.user),paginate:!0},{Header:(0,o.t)("Created by"),id:"created_by",input:"select",operator:x.p.relationOneMany,unfilteredLabel:(0,o.t)("All"),fetchSelects:(0,b.tm)("chart","created_by",(0,b.v$)((e=>t((0,o.t)("An error occurred while fetching chart created by values: %s",e)))),e.user),paginate:!0},{Header:(0,o.t)("Chart type"),id:"viz_type",input:"select",operator:x.p.equals,unfilteredLabel:(0,o.t)("All"),selects:O.keys().filter((e=>{var t;return(0,I.X3)((null==(t=O.get(e))?void 0:t.behaviors)||[])})).map((e=>{var t;return{label:(null==(t=O.get(e))?void 0:t.name)||e,value:e}})).sort(((e,t)=>e.label&&t.label?e.label>t.label?1:e.label<t.label?-1:0:0))},{Header:(0,o.t)("Dataset"),id:"datasource_id",input:"select",operator:x.p.equals,unfilteredLabel:(0,o.t)("All"),fetchSelects:L,paginate:!0},...l?[pe]:[],{Header:(0,o.t)("Certified"),id:"id",urlDisplay:"certified",input:"select",operator:x.p.chartIsCertified,unfilteredLabel:(0,o.t)("Any"),selects:[{label:(0,o.t)("Yes"),value:!0},{label:(0,o.t)("No"),value:!1}]},{Header:(0,o.t)("Search"),id:"slice_name",input:"search",operator:x.p.chartAllText}]),[t,pe,e.user]),he=[{desc:!1,id:"slice_name",label:(0,o.t)("Alphabetical"),value:"alphabetical"},{desc:!0,id:"changed_on_delta_humanized",label:(0,o.t)("Recently modified"),value:"recently_modified"},{desc:!1,id:"changed_on_delta_humanized",label:(0,o.t)("Least recently modified"),value:"least_recently_modified"}],ge=(0,d.useCallback)((e=>(0,z.tZ)(M.Z,{chart:e,showThumbnails:re?re.thumbnails:(0,h.cr)(g.T.THUMBNAILS),hasPerm:E,openChartEditModal:X,bulkSelectEnabled:c,addDangerToast:t,addSuccessToast:a,refreshData:q,userId:l,loading:r,favoriteStatus:W[e.id],saveFavoriteStatus:j,handleBulkChartExport:ce})),[t,a,c,W,E,r]),be=[];return(se||ne)&&be.push({name:(0,o.t)("Bulk select"),buttonStyle:"secondary","data-test":"bulk-select",onClick:P}),ie&&(be.push({name:(0,z.tZ)(d.Fragment,null,(0,z.tZ)("i",{className:"fa fa-plus"})," ",(0,o.t)("Chart")),buttonStyle:"primary",onClick:()=>{window.location.assign("/chart/add")}}),(0,h.cr)(g.T.VERSIONED_EXPORT)&&be.push({name:(0,z.tZ)($.u,{id:"import-tooltip",title:(0,o.t)("Import charts"),placement:"bottomRight"},(0,z.tZ)(N.Z.Import,null)),buttonStyle:"link",onClick:()=>{Q(!0)}})),(0,z.tZ)(d.Fragment,null,(0,z.tZ)(Z.Z,{name:(0,o.t)("Charts"),buttons:be}),K&&(0,z.tZ)(T.Z,{onHide:G,onSave:Y,show:!0,slice:K}),(0,z.tZ)(v.Z,{title:(0,o.t)("Please confirm"),description:(0,o.t)("Are you sure you want to delete the selected charts?"),onConfirm:function(e){n.Z.delete({endpoint:`/api/v1/chart/?q=${u().encode(e.map((({id:e})=>e)))}`}).then((({json:e={}})=>{q(),a(e.message)}),(0,b.v$)((e=>t((0,o.t)("There was an issue deleting the selected charts: %s",e)))))}},(e=>{const t=[];return se&&t.push({key:"delete",name:(0,o.t)("Delete"),type:"danger",onSelect:e}),ne&&t.push({key:"export",name:(0,o.t)("Export"),type:"primary",onSelect:ce}),(0,z.tZ)(x.Z,{bulkActions:t,bulkSelectEnabled:c,cardSortSelectOptions:he,className:"chart-list-view",columns:ue,count:i,data:s,disableBulkSelect:P,fetchData:H,filters:me,initialSort:de,loading:r,pageSize:25,renderCard:ge,showThumbnails:re?re.thumbnails:(0,h.cr)(g.T.THUMBNAILS),defaultViewMode:(0,h.cr)(g.T.LISTVIEWS_DEFAULT_CARD_VIEW)?"card":"table"})})),(0,z.tZ)(k.Z,{resourceName:"chart",resourceLabel:(0,o.t)("chart"),passwordsNeededMessage:U,confirmOverwriteMessage:B,addDangerToast:t,addSuccessToast:a,onModelImport:()=>{Q(!1),q(),a((0,o.t)("Chart imported"))},show:J,onHide:()=>{Q(!1)},passwordFields:ee,setPasswordFields:te}),ae&&(0,z.tZ)(S.Z,null))}))}}]);
//# sourceMappingURL=3f608e1de859a8901191.chunk.js.map