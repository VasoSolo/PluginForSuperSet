(()=>{var e,t,a,n,i,r,o,d,l={43063:(e,t,a)=>{var n=a(34963),i=a(80760),r=a(67206),o=a(1469),d=a(94885);e.exports=function(e,t){return(o(e)?n:i)(e,d(r(t,3)))}},19259:(e,t,a)=>{"use strict";a.d(t,{Z:()=>o});var n=a(67294),i=a(17198),r=a(11965);function o({title:e,description:t,onConfirm:a,children:o}){const[d,l]=(0,n.useState)(!1),[s,c]=(0,n.useState)([]),u=()=>{l(!1),c([])};return(0,r.tZ)(n.Fragment,null,o&&o(((...e)=>{e.forEach((e=>{e&&("function"==typeof e.persist&&e.persist(),"function"==typeof e.preventDefault&&e.preventDefault(),"function"==typeof e.stopPropagation&&e.stopPropagation())})),l(!0),c(e)})),(0,r.tZ)(i.Z,{description:t,onConfirm:()=>{a(...s),u()},onHide:u,open:d,title:e}))}},55467:(e,t,a)=>{"use strict";a.d(t,{Z:()=>E});var n=a(11965),i=a(67294),r=a(51995),o=a(26506),d=a(58593),l=a(5872),s=a.n(l),c=a(68492);const u=r.iK.div`
  background-image: url(${({src:e})=>e});
  background-size: cover;
  background-position: center ${({position:e})=>e};
  display: inline-block;
  height: calc(100% - 1px);
  width: calc(100% - 2px);
  margin: 1px 1px 0 1px;
`;function b({src:e,fallback:t,isLoading:a,position:r,...o}){const[d,l]=(0,i.useState)(t);return(0,i.useEffect)((()=>(e&&fetch(e).then((e=>e.blob())).then((e=>{if(/image/.test(e.type)){const t=URL.createObjectURL(e);l(t)}})).catch((e=>{c.Z.error(e),l(t)})),()=>{l(t)})),[e,t]),(0,n.tZ)(u,s()({src:a?t:d},o,{position:r}))}var f=a(79789);const h=r.iK.div`
  width: 64px;
  display: flex;
  justify-content: flex-end;
`,m=(0,r.iK)(o.Ak)`
  ${({theme:e})=>`\n    border: 1px solid ${e.colors.grayscale.light2};\n    border-radius: ${e.gridUnit}px;\n    overflow: hidden;\n\n    .ant-card-body {\n      padding: ${4*e.gridUnit}px\n        ${2*e.gridUnit}px;\n    }\n    .ant-card-meta-detail > div:not(:last-child) {\n      margin-bottom: 0;\n    }\n    .gradient-container {\n      position: relative;\n      height: 100%;\n    }\n    &:hover {\n      box-shadow: 8px 8px 28px 0px ${e.colors.grayscale.light1};\n      transition: box-shadow ${e.transitionTiming}s ease-in-out;\n\n      .cover-footer {\n        transform: translateY(0);\n      }\n    }\n  `}
`,p=r.iK.div`
  height: 264px;
  border-bottom: 1px solid ${({theme:e})=>e.colors.grayscale.light2};
  overflow: hidden;

  .cover-footer {
    transform: translateY(${({theme:e})=>9*e.gridUnit}px);
    transition: ${({theme:e})=>e.transitionTiming}s ease-out;
  }
`,g=r.iK.div`
  display: flex;
  justify-content: flex-start;
  flex-direction: row;

  .card-actions {
    margin-left: auto;
    align-self: flex-end;
    padding-left: ${({theme:e})=>e.gridUnit}px;
    span[role='img'] {
      display: flex;
      align-items: center;
    }
  }
`,v=r.iK.span`
  overflow: hidden;
  text-overflow: ellipsis;
  & a {
    color: ${({theme:e})=>e.colors.grayscale.dark1} !important;
  }
`,Z=r.iK.span`
  position: absolute;
  right: -1px;
  bottom: ${({theme:e})=>e.gridUnit}px;
`,y=r.iK.div`
  display: flex;
  flex-wrap: nowrap;
  position: relative;
  top: -${({theme:e})=>9*e.gridUnit}px;
  padding: 0 8px;
`,x=r.iK.div`
  flex: 1;
  overflow: hidden;
`,w=r.iK.div`
  align-self: flex-end;
  margin-left: auto;
  max-width: 200px;
  overflow: hidden;
  text-overflow: ellipsis;
`,_=(0,r.iK)(o.Od)`
  h3 {
    margin: ${({theme:e})=>e.gridUnit}px 0;
  }

  ul {
    margin-bottom: 0;
  }
`,C={rows:1,width:150},k=({to:e,children:t})=>(0,n.tZ)("a",{href:e},t);function S({title:e,url:t,linkComponent:a,titleRight:l,imgURL:s,imgFallbackURL:c,description:u,coverLeft:h,coverRight:S,actions:E,avatar:$,loading:T,imgPosition:I="top",cover:N,certifiedBy:D,certificationDetails:R}){const U=t&&a?a:k,A=(0,r.Fg)();return(0,n.tZ)(m,{cover:N||(0,n.tZ)(p,null,(0,n.tZ)(U,{to:t},(0,n.tZ)("div",{className:"gradient-container"},(0,n.tZ)(b,{src:s||"",fallback:c||"",isLoading:T,position:I}))),(0,n.tZ)(y,{className:"cover-footer"},!T&&h&&(0,n.tZ)(x,null,h),!T&&S&&(0,n.tZ)(w,null,S)))},T&&(0,n.tZ)(o.Ak.Meta,{title:(0,n.tZ)(i.Fragment,null,(0,n.tZ)(g,null,(0,n.tZ)(o.Od.Input,{active:!0,size:"small",css:(0,n.iv)({width:Math.trunc(62.5*A.gridUnit)},"","")}),(0,n.tZ)("div",{className:"card-actions"},(0,n.tZ)(o.Od.Button,{active:!0,shape:"circle"})," ",(0,n.tZ)(o.Od.Button,{active:!0,css:(0,n.iv)({width:10*A.gridUnit},"","")})))),description:(0,n.tZ)(_,{round:!0,active:!0,title:!1,paragraph:C})}),!T&&(0,n.tZ)(o.Ak.Meta,{title:(0,n.tZ)(g,null,(0,n.tZ)(d.u,{title:e},(0,n.tZ)(v,null,(0,n.tZ)(U,{to:t},D&&(0,n.tZ)(i.Fragment,null,(0,n.tZ)(f.Z,{certifiedBy:D,details:R})," "),e))),l&&(0,n.tZ)(Z,null,l),(0,n.tZ)("div",{className:"card-actions"},E)),description:u,avatar:$||null}))}S.Actions=h;const E=S},83673:(e,t,a)=>{"use strict";a.d(t,{Z:()=>Z});var n=a(67294),i=a(74069),r=a(9875),o=a(35932),d=a(26506),l=a(15926),s=a.n(l),c=a(51995),u=a(61988),b=a(31069),f=a(98286),h=a(14114),m=a(11965);const p=d.qz.Item,g=(0,c.iK)(d.qz.Item)`
  margin-bottom: 0;
`,v=c.iK.span`
  margin-bottom: 0;
`,Z=(0,h.ZP)((function({slice:e,onHide:t,onSave:a,show:l,addSuccessToast:c}){const[h,Z]=(0,n.useState)(!1),[y]=d.qz.useForm(),[x,w]=(0,n.useState)(e.slice_name||""),[_,C]=(0,n.useState)(null);function k({error:e,statusText:t,message:a}){let n=e||t||(0,u.t)("An error has occurred");"Forbidden"===a&&(n=(0,u.t)("You do not have permission to edit this chart")),i.Z.error({title:"Error",content:n,okButtonProps:{danger:!0,className:"btn-danger"}})}const S=(0,n.useCallback)((async function(){try{var t;const a=(await b.Z.get({endpoint:`/api/v1/chart/${e.slice_id}`})).json.result;C(null==a||null==(t=a.owners)?void 0:t.map((e=>({value:e.id,label:`${e.first_name} ${e.last_name}`}))))}catch(e){k(await(0,f.O)(e))}}),[e.slice_id]),E=(0,n.useMemo)((()=>(e="",t,a)=>{const n=s().encode({filter:e,page:t,page_size:a});return b.Z.get({endpoint:`/api/v1/chart/related/owners?q=${n}`}).then((e=>({data:e.json.result.map((e=>({value:e.value,label:e.text}))),totalCount:e.json.count})))}),[]),$=(0,u.t)("Owners");return(0,n.useEffect)((()=>{S()}),[S]),(0,n.useEffect)((()=>{w(e.slice_name||"")}),[e.slice_name]),(0,m.tZ)(i.Z,{show:l,onHide:t,title:"Edit Chart Properties",footer:(0,m.tZ)(n.Fragment,null,(0,m.tZ)(o.Z,{htmlType:"button",buttonSize:"small",onClick:t,cta:!0},(0,u.t)("Cancel")),(0,m.tZ)(o.Z,{htmlType:"submit",buttonSize:"small",buttonStyle:"primary",onClick:y.submit,disabled:h||!x||e.is_managed_externally,tooltip:e.is_managed_externally?(0,u.t)("This chart is managed externally, and can't be edited in Superset"):"",cta:!0},(0,u.t)("Save"))),responsive:!0,wrapProps:{"data-test":"properties-edit-modal"}},(0,m.tZ)(d.qz,{form:y,onFinish:async n=>{Z(!0);const{certified_by:i,certification_details:r,description:o,cache_timeout:d}=n,l={slice_name:x||null,description:o||null,cache_timeout:d||null,certified_by:i||null,certification_details:i&&r?r:null};_&&(l.owners=_.map((e=>e.value)));try{const n=await b.Z.put({endpoint:`/api/v1/chart/${e.slice_id}`,headers:{"Content-Type":"application/json"},body:JSON.stringify(l)}),i={...l,...n.json.result,id:e.slice_id};a(i),c((0,u.t)("Chart properties updated")),t()}catch(e){k(await(0,f.O)(e))}Z(!1)},layout:"vertical",initialValues:{name:e.slice_name||"",description:e.description||"",cache_timeout:null!=e.cache_timeout?e.cache_timeout:"",certified_by:e.certified_by||"",certification_details:e.certified_by&&e.certification_details?e.certification_details:""}},(0,m.tZ)(d.X2,{gutter:16},(0,m.tZ)(d.JX,{xs:24,md:12},(0,m.tZ)("h3",null,(0,u.t)("Basic information")),(0,m.tZ)(p,{label:(0,u.t)("Name"),required:!0},(0,m.tZ)(r.II,{"aria-label":(0,u.t)("Name"),name:"name",type:"text",value:x,onChange:e=>{var t;return w(null!=(t=e.target.value)?t:"")}})),(0,m.tZ)(p,null,(0,m.tZ)(g,{label:(0,u.t)("Description"),name:"description"},(0,m.tZ)(r.Kx,{rows:3,style:{maxWidth:"100%"}})),(0,m.tZ)(v,{className:"help-block"},(0,u.t)("The description can be displayed as widget headers in the dashboard view. Supports markdown."))),(0,m.tZ)("h3",null,(0,u.t)("Certification")),(0,m.tZ)(p,null,(0,m.tZ)(g,{label:(0,u.t)("Certified by"),name:"certified_by"},(0,m.tZ)(r.II,{"aria-label":(0,u.t)("Certified by")})),(0,m.tZ)(v,{className:"help-block"},(0,u.t)("Person or group that has certified this chart."))),(0,m.tZ)(p,null,(0,m.tZ)(g,{label:(0,u.t)("Certification details"),name:"certification_details"},(0,m.tZ)(r.II,{"aria-label":(0,u.t)("Certification details")})),(0,m.tZ)(v,{className:"help-block"},(0,u.t)("Any additional detail to show in the certification tooltip.")))),(0,m.tZ)(d.JX,{xs:24,md:12},(0,m.tZ)("h3",null,(0,u.t)("Configuration")),(0,m.tZ)(p,null,(0,m.tZ)(g,{label:(0,u.t)("Cache timeout"),name:"cache_timeout"},(0,m.tZ)(r.II,{"aria-label":"Cache timeout"})),(0,m.tZ)(v,{className:"help-block"},(0,u.t)("Duration (in seconds) of the caching timeout for this chart. Note this defaults to the dataset's timeout if undefined."))),(0,m.tZ)("h3",{style:{marginTop:"1em"}},(0,u.t)("Access")),(0,m.tZ)(p,{label:$},(0,m.tZ)(d.qb,{ariaLabel:$,mode:"multiple",name:"owners",value:_||[],onChange:C,options:E,disabled:!_,allowClear:!0}),(0,m.tZ)(v,{className:"help-block"},(0,u.t)("A list of users who can alter the chart. Searchable by name or username.")))))))}))},33626:(e,t,a)=>{"use strict";a.d(t,{J:()=>i});var n=a(67294);const i=e=>{(0,n.useEffect)(e,[])}},32228:(e,t,a)=>{"use strict";a.d(t,{Z:()=>l});var n=a(89816),i=a(15926),r=a.n(i),o=a(14670),d=a.n(o);function l(e,t,a,i=200){const o=d().generate(),l=`/api/v1/${e}/export/?q=${r().encode(t)}&token=${o}`,s=document.createElement("iframe");s.style.display="none",s.src=l,document.body.appendChild(s);const c=window.setInterval((()=>{"done"===(0,n.Z)()[o]&&(window.clearInterval(c),document.body.removeChild(s),a())}),i)}},34024:(e,t,a)=>{"use strict";a.d(t,{Z:()=>y});var n=a(67294),i=a(51995),r=a(61988),o=a(5977),d=a(73727),l=a(91877),s=a(93185),c=a(19259),u=a(70163),b=a(55467),f=a(37921),h=a(26506),m=a(83862),p=a(36674),g=a(34581),v=a(40768),Z=a(11965);function y({chart:e,hasPerm:t,openChartEditModal:a,bulkSelectEnabled:y,addDangerToast:x,addSuccessToast:w,refreshData:_,loading:C,showThumbnails:k,saveFavoriteStatus:S,favoriteStatus:E,chartFilter:$,userId:T,handleBulkChartExport:I}){const N=(0,o.k6)(),D=t("can_write"),R=t("can_write"),U=t("can_export")&&(0,l.cr)(s.T.VERSIONED_EXPORT),A=(0,i.Fg)(),F=(0,Z.tZ)(m.v,null,R&&(0,Z.tZ)(m.v.Item,null,(0,Z.tZ)(c.Z,{title:(0,r.t)("Please confirm"),description:(0,Z.tZ)(n.Fragment,null,(0,r.t)("Are you sure you want to delete")," ",(0,Z.tZ)("b",null,e.slice_name),"?"),onConfirm:()=>(0,v.Gm)(e,w,x,_,$,T)},(e=>(0,Z.tZ)("div",{role:"button",tabIndex:0,className:"action-button",onClick:e},(0,Z.tZ)(u.Z.Trash,{iconSize:"l"})," ",(0,r.t)("Delete"))))),U&&(0,Z.tZ)(m.v.Item,null,(0,Z.tZ)("div",{role:"button",tabIndex:0,onClick:()=>I([e])},(0,Z.tZ)(u.Z.Share,{iconSize:"l"})," ",(0,r.t)("Export"))),D&&(0,Z.tZ)(m.v.Item,null,(0,Z.tZ)("div",{role:"button",tabIndex:0,onClick:()=>a(e)},(0,Z.tZ)(u.Z.EditAlt,{iconSize:"l"})," ",(0,r.t)("Edit"))));return(0,Z.tZ)(v.ZB,{onClick:()=>{!y&&e.url&&N.push(e.url)}},(0,Z.tZ)(b.Z,{loading:C,title:e.slice_name,certifiedBy:e.certified_by,certificationDetails:e.certification_details,cover:(0,l.cr)(s.T.THUMBNAILS)&&k?null:(0,Z.tZ)(n.Fragment,null),url:y?void 0:e.url,imgURL:e.thumbnail_url||"",imgFallbackURL:"/static/assets/images/chart-card-fallback.svg",description:(0,r.t)("Modified %s",e.changed_on_delta_humanized),coverLeft:(0,Z.tZ)(g.Z,{users:e.owners||[]}),coverRight:(0,Z.tZ)(f.Z,{type:"secondary"},e.datasource_name_text),linkComponent:d.rU,actions:(0,Z.tZ)(b.Z.Actions,{onClick:e=>{e.stopPropagation(),e.preventDefault()}},T&&(0,Z.tZ)(p.Z,{itemId:e.id,saveFaveStar:S,isStarred:E}),(0,Z.tZ)(h.Gj,{overlay:F},(0,Z.tZ)(u.Z.MoreVert,{iconColor:A.colors.grayscale.base})))}))}},99415:(e,t,a)=>{"use strict";a.d(t,{Z:()=>y});var n=a(67294),i=a(5977),r=a(73727),o=a(51995),d=a(61988),l=a(40768),s=a(91877),c=a(93185),u=a(26506),b=a(83862),f=a(19259),h=a(55467),m=a(70163),p=a(37921),g=a(34581),v=a(36674),Z=a(11965);const y=function({dashboard:e,hasPerm:t,bulkSelectEnabled:a,dashboardFilter:y,refreshData:x,userId:w,addDangerToast:_,addSuccessToast:C,openDashboardEditModal:k,favoriteStatus:S,saveFavoriteStatus:E,showThumbnails:$,handleBulkDashboardExport:T}){const I=(0,i.k6)(),N=t("can_write"),D=t("can_write"),R=t("can_export"),U=(0,o.Fg)(),A=(0,Z.tZ)(b.v,null,N&&k&&(0,Z.tZ)(b.v.Item,null,(0,Z.tZ)("div",{role:"button",tabIndex:0,className:"action-button",onClick:()=>k&&k(e)},(0,Z.tZ)(m.Z.EditAlt,{iconSize:"l"})," ",(0,d.t)("Edit"))),R&&(0,Z.tZ)(b.v.Item,null,(0,Z.tZ)("div",{role:"button",tabIndex:0,onClick:()=>T([e]),className:"action-button"},(0,Z.tZ)(m.Z.Share,{iconSize:"l"})," ",(0,d.t)("Export"))),D&&(0,Z.tZ)(b.v.Item,null,(0,Z.tZ)(f.Z,{title:(0,d.t)("Please confirm"),description:(0,Z.tZ)(n.Fragment,null,(0,d.t)("Are you sure you want to delete")," ",(0,Z.tZ)("b",null,e.dashboard_title),"?"),onConfirm:()=>(0,l.Iu)(e,x,C,_,y,w)},(e=>(0,Z.tZ)("div",{role:"button",tabIndex:0,className:"action-button",onClick:e},(0,Z.tZ)(m.Z.Trash,{iconSize:"l"})," ",(0,d.t)("Delete"))))));return(0,Z.tZ)(l.ZB,{onClick:()=>{a||I.push(e.url)}},(0,Z.tZ)(h.Z,{loading:e.loading||!1,title:e.dashboard_title,certifiedBy:e.certified_by,certificationDetails:e.certification_details,titleRight:(0,Z.tZ)(p.Z,null,e.published?(0,d.t)("published"):(0,d.t)("draft")),cover:(0,s.cr)(c.T.THUMBNAILS)&&$?null:(0,Z.tZ)(n.Fragment,null),url:a?void 0:e.url,linkComponent:r.rU,imgURL:e.thumbnail_url,imgFallbackURL:"/static/assets/images/dashboard-card-fallback.svg",description:(0,d.t)("Modified %s",e.changed_on_delta_humanized),coverLeft:(0,Z.tZ)(g.Z,{users:e.owners||[]}),actions:(0,Z.tZ)(h.Z.Actions,{onClick:e=>{e.stopPropagation(),e.preventDefault()}},w&&(0,Z.tZ)(v.Z,{itemId:e.id,saveFaveStar:E,isStarred:S}),(0,Z.tZ)(u.Gj,{overlay:A},(0,Z.tZ)(m.Z.MoreVert,{iconColor:U.colors.grayscale.base})))}))}},12:(e,t,a)=>{"use strict";var n,i;a.d(t,{s:()=>n,J:()=>i}),function(e){e.FAVORITE="Favorite",e.MINE="Mine",e.EXAMPLES="Examples"}(n||(n={})),function(e){e.id="id",e.changed_on="changed_on",e.database="database",e.database_name="database.database_name",e.schema="schema",e.sql="sql",e.executed_sql="exceuted_sql",e.sql_tables="sql_tables",e.status="status",e.tab_name="tab_name",e.user="user",e.user_first_name="user.first_name",e.start_time="start_time",e.end_time="end_time",e.rows="rows",e.tmp_table_name="tmp_table_name",e.tracking_url="tracking_url"}(i||(i={}))},20755:(e,t,a)=>{"use strict";a.d(t,{Z:()=>x});var n=a(23279),i=a.n(n),r=a(67294),o=a(5977),d=a(73727),l=a(51995),s=a(11965),c=a(61988),u=a(94184),b=a.n(u),f=a(58593),h=a(26506),m=a(83862),p=a(35932),g=a(70163);const v=l.iK.div`
  margin-bottom: ${({theme:e})=>4*e.gridUnit}px;
  .header {
    font-weight: ${({theme:e})=>e.typography.weights.bold};
    margin-right: ${({theme:e})=>3*e.gridUnit}px;
    text-align: left;
    font-size: 18px;
    padding: ${({theme:e})=>3*e.gridUnit}px;
    display: inline-block;
    line-height: ${({theme:e})=>9*e.gridUnit}px;
  }
  .nav-right {
    display: flex;
    align-items: center;
    padding: ${({theme:e})=>3.5*e.gridUnit}px 0;
    margin-right: ${({theme:e})=>3*e.gridUnit}px;
    float: right;
    position: absolute;
    right: 0;
    ul.ant-menu-root {
      padding: 0px;
    }
    li[role='menuitem'] {
      border: 0;
      border-bottom: none;
      &:hover {
        border-bottom: transparent;
      }
    }
  }
  .nav-right-collapse {
    display: flex;
    align-items: center;
    padding: 14px 0;
    margin-right: 0;
    float: left;
    padding-left: 10px;
  }
  .menu {
    background-color: ${({theme:e})=>e.colors.grayscale.light5};
    .ant-menu-horizontal {
      line-height: inherit;
      .ant-menu-item {
        border-bottom: none;
        &:hover {
          border-bottom: none;
          text-decoration: none;
        }
      }
    }
    .ant-menu {
      padding: ${({theme:e})=>4*e.gridUnit}px 0px;
    }
  }

  .ant-menu-horizontal:not(.ant-menu-dark) > .ant-menu-item {
    margin: 0 ${({theme:e})=>e.gridUnit+1}px;
  }

  .menu .ant-menu-item {
    li,
    div {
      a,
      div {
        font-size: ${({theme:e})=>e.typography.sizes.s}px;
        color: ${({theme:e})=>e.colors.secondary.dark1};

        a {
          margin: 0;
          padding: ${({theme:e})=>2*e.gridUnit}px
            ${({theme:e})=>4*e.gridUnit}px;
          line-height: ${({theme:e})=>5*e.gridUnit}px;

          &:hover {
            text-decoration: none;
          }
        }
      }

      &.no-router a {
        padding: ${({theme:e})=>2*e.gridUnit}px
          ${({theme:e})=>4*e.gridUnit}px;
      }

      &.active a {
        background: ${({theme:e})=>e.colors.secondary.light4};
        border-radius: ${({theme:e})=>e.borderRadius}px;
      }
    }

    li.active > a,
    li.active > div,
    div.active > div,
    li > a:hover,
    li > a:focus,
    li > div:hover,
    div > div:hover,
    div > a:hover {
      background: ${({theme:e})=>e.colors.secondary.light4};
      border-bottom: none;
      border-radius: ${({theme:e})=>e.borderRadius}px;
      margin-bottom: ${({theme:e})=>2*e.gridUnit}px;
      text-decoration: none;
    }
  }

  .btn-link {
    padding: 10px 0;
  }
  .ant-menu-horizontal {
    border: none;
  }
  @media (max-width: 767px) {
    .header,
    .nav-right {
      position: relative;
      margin-left: ${({theme:e})=>2*e.gridUnit}px;
    }
  }
  .ant-menu-submenu {
    span[role='img'] {
      position: absolute;
      right: ${({theme:e})=>-e.gridUnit-2}px;
      top: ${({theme:e})=>e.gridUnit+1}px !important;
    }
  }
  .dropdown-menu-links > div.ant-menu-submenu-title,
  .ant-menu-submenu-open.ant-menu-submenu-active > div.ant-menu-submenu-title {
    color: ${({theme:e})=>e.colors.primary.dark1};
  }
`,Z=e=>s.iv`
  color: ${e.colors.grayscale.base};
  backgroundColor: ${e.colors.grayscale.light2}};

  .ant-menu-item:hover {
    color: ${e.colors.grayscale.base};
    cursor: default;
  }
`,{SubMenu:y}=m.$,x=e=>{var t,a,n;const[l,u]=(0,r.useState)("horizontal"),[x,w]=(0,r.useState)("nav-right");let _=!0;try{(0,o.k6)()}catch(e){_=!1}return(0,r.useEffect)((()=>{function t(){window.innerWidth<=767?u("inline"):u("horizontal"),e.buttons&&e.buttons.length>=3&&window.innerWidth>=795?w("nav-right"):e.buttons&&e.buttons.length>=3&&window.innerWidth<=795&&w("nav-right-collapse")}t();const a=i()(t,10);return window.addEventListener("resize",a),()=>window.removeEventListener("resize",a)}),[e.buttons]),(0,s.tZ)(v,null,(0,s.tZ)(h.X2,{className:"menu",role:"navigation"},e.name&&(0,s.tZ)("div",{className:"header"},e.name),(0,s.tZ)(m.v,{mode:l,style:{backgroundColor:"transparent"}},null==(t=e.tabs)?void 0:t.map((t=>(e.usesRouter||_)&&t.usesRouter?(0,s.tZ)(m.v.Item,{key:t.label},(0,s.tZ)("div",{role:"tab",className:t.name===e.activeChild?"active":""},(0,s.tZ)("div",null,(0,s.tZ)(d.rU,{to:t.url||""},t.label)))):(0,s.tZ)(m.v.Item,{key:t.label},(0,s.tZ)("div",{className:b()("no-router",{active:t.name===e.activeChild}),role:"tab"},(0,s.tZ)("a",{href:t.url,onClick:t.onClick},t.label)))))),(0,s.tZ)("div",{className:x},(0,s.tZ)(m.v,{mode:"horizontal",triggerSubMenuAction:"click"},null==(a=e.dropDownLinks)?void 0:a.map(((e,t)=>{var a;return(0,s.tZ)(y,{key:t,title:e.label,icon:(0,s.tZ)(g.Z.TriangleDown,null),popupOffset:[10,20],className:"dropdown-menu-links"},null==(a=e.childs)?void 0:a.map((e=>"object"==typeof e?e.disable?(0,s.tZ)(m.$.Item,{key:e.label,css:Z},(0,s.tZ)(f.u,{placement:"top",title:(0,c.t)("Enable 'Allow data upload' in any database's settings")},e.label)):(0,s.tZ)(m.$.Item,{key:e.label},(0,s.tZ)("a",{href:e.url},e.label)):null)))}))),null==(n=e.buttons)?void 0:n.map(((e,t)=>(0,s.tZ)(p.Z,{key:t,buttonStyle:e.buttonStyle,onClick:e.onClick},e.name))))),e.children)}},71644:(e,t,a)=>{"use strict";var n=a(67294),i=a(90731),r=a(5872),o=a.n(r),d=a(73727),l=a(5977),s=a(31405),c=a(57902),u=a(38703),b=a(77230),f=a(35260),h=a(14890),m=a(37703),p=a(51995),g=a(11965),v=a(94184),Z=a.n(v),y=a(13423),x=a(70163),w=a(1927);const _=p.iK.div`
  display: flex;
  justify-content: center;
  align-items: center;

  span {
    padding: 0 11px;
  }
`,C=e=>g.iv`
  min-width: ${5*e.gridUnit}px;
  color: ${e.colors.grayscale.base};
`;function k({toast:e,onCloseToast:t}){const a=(0,n.useRef)(),[i,r]=(0,n.useState)(!1),o=()=>{r(!0)},d=(0,n.useCallback)((()=>{a.current&&clearTimeout(a.current),r((()=>(setTimeout((()=>{t(e.id)}),150),!1)))}),[t,e.id]);(0,n.useEffect)((()=>(setTimeout(o),e.duration>0&&(a.current=setTimeout(d,e.duration)),()=>{a.current&&clearTimeout(a.current)})),[d,e.duration]);let l="toast--success",s=(0,g.tZ)(x.Z.CircleCheckSolid,{css:e=>C(e)});return e.toastType===w.p.WARNING?(s=(0,g.tZ)(x.Z.WarningSolid,{css:C}),l="toast--warning"):e.toastType===w.p.DANGER?(s=(0,g.tZ)(x.Z.ErrorSolid,{css:C}),l="toast--danger"):e.toastType===w.p.INFO&&(s=(0,g.tZ)(x.Z.InfoSolid,{css:C}),l="toast--info"),(0,g.tZ)(_,{className:Z()("alert","toast",i&&"toast--visible",l),role:"alert"},s,(0,g.tZ)(y.ZP,{content:e.text}),(0,g.tZ)("i",{className:"fa fa-close pull-right pointer",role:"button",tabIndex:0,onClick:d,"aria-label":"Close"}))}const S=p.iK.div`
  max-width: 600px;
  position: fixed;
  ${({position:e})=>"bottom"===e?"bottom":"top"}: 0px;
  right: 0px;
  margin-right: 50px;
  margin-bottom: 50px;
  z-index: ${({theme:e})=>e.zIndex.max};
  word-break: break-word;

  .toast {
    background: ${({theme:e})=>e.colors.grayscale.dark1};
    border-radius: ${({theme:e})=>e.borderRadius};
    box-shadow: 0 2px 4px 0
      fade(
        ${({theme:e})=>e.colors.grayscale.dark2},
        ${({theme:e})=>e.opacity.mediumLight}
      );
    color: ${({theme:e})=>e.colors.grayscale.light5};
    opacity: 0;
    position: relative;
    transform: translateY(-100%);
    white-space: pre-line;
    will-change: transform, opacity;
    transition: transform ${({theme:e})=>e.transitionTiming}s,
      opacity ${({theme:e})=>e.transitionTiming}s;

    &:after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 6px;
      height: 100%;
    }
  }

  .toast > button {
    color: ${({theme:e})=>e.colors.grayscale.light5};
    opacity: 1;
  }

  .toast--visible {
    opacity: 1;
    transform: translateY(0);
  }
`;var E=a(72570);const $=(0,m.$j)((({messageToasts:e})=>({toasts:e})),(e=>(0,h.DE)({removeToast:E.RS},e)))((function({toasts:e,removeToast:t,position:a="bottom"}){return(0,g.tZ)(n.Fragment,null,e.length>0&&(0,g.tZ)(S,{id:"toast-presenter",position:a},e.map((e=>(0,g.tZ)(k,{key:e.id,toast:e,onCloseToast:t})))))}));var T,I=a(38552),N=a(2120),D=a(43063),R=a.n(D),U=a(75049),A=a(61988),F=a(43700),L=a(61337),P=a(55467),z=a(14114),M=a(40768),q=a(91877),O=a(93185),j=a(26506),V=a(30381),B=a.n(V),K=a(20755),H=a(35932);!function(e){e.Charts="CHARTS",e.Dashboards="DASHBOARDS",e.Recents="RECENTS",e.SavedQueries="SAVED_QUERIES"}(T||(T={}));const Q={[T.Charts]:(0,A.t)("charts"),[T.Dashboards]:(0,A.t)("dashboards"),[T.Recents]:(0,A.t)("recents"),[T.SavedQueries]:(0,A.t)("saved queries")},Y=p.iK.div`
  min-height: 200px;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
`,X=p.iK.div`
  Button {
    svg {
      color: ${({theme:e})=>e.colors.grayscale.light5};
    }
  }
`;function W({tableName:e,tab:t}){const a={[T.Charts]:"/chart/add",[T.Dashboards]:"/dashboard/new",[T.SavedQueries]:"/superset/sqllab?new=true"},n={[T.Charts]:"/chart/list",[T.Dashboards]:"/dashboard/list/",[T.SavedQueries]:"/savedqueryview/list/"},i={[T.Charts]:"empty-charts.svg",[T.Dashboards]:"empty-dashboard.svg",[T.Recents]:"union.svg",[T.SavedQueries]:"empty-queries.svg"},r=(0,g.tZ)("span",null,(0,A.t)("No %(tableName)s yet",{tableName:Q[e]})),o=(0,g.tZ)("span",{className:"no-recents"},"Viewed"===t?(0,A.t)("Recently viewed charts, dashboards, and saved queries will appear here"):"Created"===t?(0,A.t)("Recently created charts, dashboards, and saved queries will appear here"):"Examples"===t?(0,A.t)("Example %(tableName)s will appear here",{tableName:e.toLowerCase()}):"Edited"===t?(0,A.t)("Recently edited charts, dashboards, and saved queries will appear here"):null);return"Mine"===t||"RECENTS"===e||"Examples"===t?(0,g.tZ)(Y,null,(0,g.tZ)(j.HY,{image:`/static/assets/images/${i[e]}`,description:"RECENTS"===e||"Examples"===t?o:r},"RECENTS"!==e&&(0,g.tZ)(X,null,(0,g.tZ)(H.Z,{buttonStyle:"primary",onClick:()=>{window.location.href=a[e]}},(0,g.tZ)("i",{className:"fa fa-plus"}),"SAVED_QUERIES"===e?(0,A.t)("SQL query"):e.split("").slice(0,e.length-1).join(""))))):(0,g.tZ)(Y,null,(0,g.tZ)(j.HY,{image:"/static/assets/images/star-circle.svg",description:(0,g.tZ)("span",{className:"no-favorites"},(0,A.t)("You don't have any favorites yet!"))},(0,g.tZ)(H.Z,{buttonStyle:"primary",onClick:()=>{window.location.href=n[e]}},(0,A.t)("See all %(tableName)s",{tableName:"SAVED_QUERIES"===e?(0,A.t)("SQL Lab queries"):Q[e]}))))}var G;!function(e){e.EDITED="Edited",e.CREATED="Created",e.VIEWED="Viewed",e.EXAMPLE="Examples"}(G||(G={}));const J=p.iK.div`
  .recentCards {
    max-height: none;
    grid-gap: ${({theme:e})=>4*e.gridUnit+"px"};
  }
`,ee=(0,A.t)("[Untitled]"),te=(0,A.t)("Unknown"),ae=e=>"dashboard_title"in e?e.dashboard_title||ee:"slice_name"in e?e.slice_name||ee:"label"in e?e.label||ee:e.item_title||ee,ne=e=>{if("sql"in e)return(0,g.tZ)(x.Z.Sql,null);const t="item_url"in e?e.item_url:e.url;return null!=t&&t.includes("dashboard")?(0,g.tZ)(x.Z.NavDashboard,null):null!=t&&t.includes("explore")?(0,g.tZ)(x.Z.NavCharts,null):null};function ie({activeChild:e,setActiveChild:t,activityData:a,user:i,loadedCount:r}){var o;const[l,s]=(0,n.useState)(),[c,u]=(0,n.useState)(!1);(0,n.useEffect)((()=>{"Edited"===e&&(u(!0),u(!0),(0,M.Ld)(i.userId).then((e=>{s([...e.editedChart,...e.editedDash]),u(!1)})))}),[e]);const b=[{name:"Edited",label:(0,A.t)("Edited"),onClick:()=>{t("Edited"),(0,L.LS)(L.dR.homepage_activity_filter,G.EDITED)}},{name:"Created",label:(0,A.t)("Created"),onClick:()=>{t("Created"),(0,L.LS)(L.dR.homepage_activity_filter,G.CREATED)}}];return null!=a&&a.Viewed&&b.unshift({name:"Viewed",label:(0,A.t)("Viewed"),onClick:()=>{t("Viewed"),(0,L.LS)(L.dR.homepage_activity_filter,G.VIEWED)}}),c&&!l||r<3?(0,g.tZ)(Ie,null):(0,g.tZ)(J,null,(0,g.tZ)(K.Z,{activeChild:e,tabs:b}),(null==(o=a[e])?void 0:o.length)>0||"Edited"===e&&l&&l.length>0?(0,g.tZ)(M._L,{className:"recentCards"},("Edited"!==e?a[e]:l).map((e=>{const t=(e=>"sql"in e?`/superset/sqllab?savedQueryId=${e.id}`:"url"in e?e.url:e.item_url)(e),a=(e=>{if("time"in e)return(0,A.t)("Viewed %s",B()(e.time).fromNow());let t;return"changed_on"in e&&(t=e.changed_on),"changed_on_utc"in e&&(t=e.changed_on_utc),(0,A.t)("Modified %s",null==t?te:B()(t).fromNow())})(e);return(0,g.tZ)(M.ZB,{key:t},(0,g.tZ)(d.rU,{to:t},(0,g.tZ)(P.Z,{cover:(0,g.tZ)(n.Fragment,null),url:t,title:ae(e),description:a,avatar:ne(e),actions:null})))}))):(0,g.tZ)(W,{tableName:T.Recents,tab:e}))}var re=a(63105),oe=a.n(re),de=a(34858),le=a(12),se=a(83673),ce=a(34024),ue=a(32228);const be=(0,z.ZP)((function({user:e,addDangerToast:t,addSuccessToast:a,mine:i,showThumbnails:r,examples:o}){const d=(0,l.k6)(),s=(0,L.rV)(L.dR.homepage_chart_filter,le.s.EXAMPLES),b=oe()(o,(e=>"viz_type"in e)),{state:{loading:f,resourceCollection:h,bulkSelectEnabled:m},setResourceCollection:p,hasPerm:v,refreshData:Z,fetchData:y}=(0,de.Yi)("chart",(0,A.t)("chart"),t,!0,"Mine"===s?i:b,[],!1),x=(0,n.useMemo)((()=>h.map((e=>e.id))),[h]),[w,_]=(0,de.NE)("chart",x,t),{sliceCurrentlyEditing:C,openChartEditModal:k,handleChartUpdated:S,closeChartEditModal:E}=(0,de.fF)(p,h),[$,I]=(0,n.useState)(s),[N,D]=(0,n.useState)(!1),[R,U]=(0,n.useState)(!1),F=t=>{const a=[];return"Mine"===t?a.push({id:"owners",operator:"rel_m_m",value:`${null==e?void 0:e.userId}`}):"Favorite"===t?a.push({id:"id",operator:"chart_is_favorite",value:!0}):"Examples"===t&&a.push({id:"created_by",operator:"rel_o_m",value:0}),a};(0,n.useEffect)((()=>{(R||"Favorite"===$)&&(e=>{y({pageIndex:0,pageSize:M.IV,sortBy:[{id:"changed_on_delta_humanized",desc:!0}],filters:F(e)})})($),U(!0)}),[$]);const P=e=>{const t=e.map((({id:e})=>e));(0,ue.Z)("chart",t,(()=>{D(!1)})),D(!0)},z=[{name:"Favorite",label:(0,A.t)("Favorite"),onClick:()=>{I(le.s.FAVORITE),(0,L.LS)(L.dR.homepage_chart_filter,le.s.FAVORITE)}},{name:"Mine",label:(0,A.t)("Mine"),onClick:()=>{I(le.s.MINE),(0,L.LS)(L.dR.homepage_chart_filter,le.s.MINE)}}];return o&&z.push({name:"Examples",label:(0,A.t)("Examples"),onClick:()=>{I(le.s.EXAMPLES),(0,L.LS)(L.dR.homepage_chart_filter,le.s.EXAMPLES)}}),f?(0,g.tZ)(Ie,{cover:r}):(0,g.tZ)(c.Z,null,C&&(0,g.tZ)(se.Z,{onHide:E,onSave:S,show:!0,slice:C}),(0,g.tZ)(K.Z,{activeChild:$,tabs:z,buttons:[{name:(0,g.tZ)(n.Fragment,null,(0,g.tZ)("i",{className:"fa fa-plus"}),(0,A.t)("Chart")),buttonStyle:"tertiary",onClick:()=>{window.location.assign("/chart/add")}},{name:(0,A.t)("View All »"),buttonStyle:"link",onClick:()=>{const e="Favorite"===$?`/chart/list/?filters=(favorite:(label:${(0,A.t)("Yes")},value:!t))`:"/chart/list/";d.push(e)}}]}),null!=h&&h.length?(0,g.tZ)(M._L,{showThumbnails:r},h.map((n=>(0,g.tZ)(ce.Z,{key:`${n.id}`,openChartEditModal:k,chartFilter:$,chart:n,userId:null==e?void 0:e.userId,hasPerm:v,showThumbnails:r,bulkSelectEnabled:m,refreshData:Z,addDangerToast:t,addSuccessToast:a,favoriteStatus:_[n.id],saveFavoriteStatus:w,handleBulkChartExport:P})))):(0,g.tZ)(W,{tableName:T.Charts,tab:$}),N&&(0,g.tZ)(u.Z,null))}));var fe=a(31069),he=a(42110),me=a(33743),pe=a(120),ge=a(83862),ve=a(17198);he.Z.registerLanguage("sql",me.Z);const Ze=p.iK.div`
  cursor: pointer;
  a {
    text-decoration: none;
  }
  .ant-card-cover {
    border-bottom: 1px solid ${({theme:e})=>e.colors.grayscale.light2};
    & > div {
      height: 171px;
    }
  }
  .gradient-container > div {
    background-size: contain;
    background-repeat: no-repeat;
    background-position: center;
    background-color: ${({theme:e})=>e.colors.secondary.light3};
    display: inline-block;
    width: 100%;
    height: 179px;
    background-repeat: no-repeat;
    vertical-align: middle;
  }
`,ye=p.iK.div`
  svg {
    margin-left: ${({theme:e})=>10*e.gridUnit}px;
  }
  .query-title {
    padding: ${({theme:e})=>2*e.gridUnit+2}px;
    font-size: ${({theme:e})=>e.typography.sizes.l}px;
  }
`,xe=p.iK.div`
  pre {
    height: ${({theme:e})=>40*e.gridUnit}px;
    border: none !important;
    background-color: ${({theme:e})=>e.colors.grayscale.light5} !important;
    overflow: hidden;
    padding: ${({theme:e})=>4*e.gridUnit}px !important;
  }
`,we=(0,z.ZP)((({user:e,addDangerToast:t,addSuccessToast:a,mine:i,showThumbnails:r,featureFlag:o})=>{const{state:{loading:d,resourceCollection:l},hasPerm:s,fetchData:c,refreshData:u}=(0,de.Yi)("saved_query",(0,A.t)("query"),t,!0,i,[],!1),[b,f]=(0,n.useState)("Mine"),[h,m]=(0,n.useState)(!1),[v,Z]=(0,n.useState)({}),[y,w]=(0,n.useState)(!0),_=s("can_edit"),C=s("can_delete"),k=(0,p.Fg)(),S=t=>{const a=[];return"Mine"===t?a.push({id:"created_by",operator:"rel_o_m",value:`${null==e?void 0:e.userId}`}):a.push({id:"id",operator:"saved_query_is_fav",value:!0}),a};return d?(0,g.tZ)(Ie,{cover:r}):(0,g.tZ)(n.Fragment,null,h&&(0,g.tZ)(ve.Z,{description:(0,A.t)("This action will permanently delete the saved query."),onConfirm:()=>{h&&(({id:n,label:i})=>{fe.Z.delete({endpoint:`/api/v1/saved_query/${n}`}).then((()=>{const t={filters:[{id:"created_by",operator:"rel_o_m",value:`${null==e?void 0:e.userId}`}],pageSize:M.IV,sortBy:[{id:"changed_on_delta_humanized",desc:!0}],pageIndex:0};u(y?t:void 0),w(!1),m(!1),a((0,A.t)("Deleted: %s",i))}),(0,M.v$)((e=>t((0,A.t)("There was an issue deleting %s: %s",i,e)))))})(v)},onHide:()=>{m(!1)},open:!0,title:(0,A.t)("Delete Query?")}),(0,g.tZ)(K.Z,{activeChild:b,tabs:[{name:"Mine",label:(0,A.t)("Mine"),onClick:()=>c({pageIndex:0,pageSize:M.IV,sortBy:[{id:"changed_on_delta_humanized",desc:!0}],filters:S("Mine")}).then((()=>f("Mine")))}],buttons:[{name:(0,g.tZ)(n.Fragment,null,(0,g.tZ)("i",{className:"fa fa-plus"}),(0,A.t)("SQL Query")),buttonStyle:"tertiary",onClick:()=>{window.location.href="/superset/sqllab?new=true"}},{name:(0,A.t)("View All »"),buttonStyle:"link",onClick:()=>{window.location.href="/savedqueryview/list"}}]}),l.length>0?(0,g.tZ)(M._L,{showThumbnails:r},l.map((e=>{var i,d,l;return(0,g.tZ)(Ze,{onClick:()=>{window.location.href=`/superset/sqllab?savedQueryId=${e.id}`},key:e.id},(0,g.tZ)(P.Z,{imgURL:"",url:`/superset/sqllab?savedQueryId=${e.id}`,title:e.label,imgFallbackURL:"/static/assets/images/empty-query.svg",description:(0,A.t)("Ran %s",e.changed_on_delta_humanized),cover:null!=e&&null!=(i=e.sql)&&i.length&&r&&o?(0,g.tZ)(xe,null,(0,g.tZ)(he.Z,{language:"sql",lineProps:{style:{color:k.colors.grayscale.dark2,wordBreak:"break-all",whiteSpace:"pre-wrap"}},style:pe.Z,wrapLines:!0,lineNumberStyle:{display:"none"},showLineNumbers:!1},(0,M.IB)(e.sql,25))):!(r&&(null==e||null==(d=e.sql)||!d.length))&&(0,g.tZ)(n.Fragment,null),actions:(0,g.tZ)(ye,null,(0,g.tZ)(P.Z.Actions,{onClick:e=>{e.stopPropagation(),e.preventDefault()}},(0,g.tZ)(j.Gj,{overlay:(l=e,(0,g.tZ)(ge.v,null,_&&(0,g.tZ)(ge.v.Item,{onClick:()=>{window.location.href=`/superset/sqllab?savedQueryId=${l.id}`}},(0,A.t)("Edit")),(0,g.tZ)(ge.v.Item,{onClick:()=>{l.id&&(0,de.bR)(l.id,t,a)}},(0,A.t)("Share")),C&&(0,g.tZ)(ge.v.Item,{onClick:()=>{m(!0),Z(l)}},(0,A.t)("Delete"))))},(0,g.tZ)(x.Z.MoreVert,{iconColor:k.colors.grayscale.base}))))}))}))):(0,g.tZ)(W,{tableName:T.SavedQueries,tab:b}))}));var _e=a(20818),Ce=a(99415);const ke=(0,z.ZP)((function({user:e,addDangerToast:t,addSuccessToast:a,mine:i,showThumbnails:r,examples:o}){const d=(0,l.k6)(),s=(0,L.rV)(L.dR.homepage_dashboard_filter,le.s.EXAMPLES),c=oe()(o,(e=>!("viz_type"in e))),{state:{loading:b,resourceCollection:f},setResourceCollection:h,hasPerm:m,refreshData:p,fetchData:v}=(0,de.Yi)("dashboard",(0,A.t)("dashboard"),t,!0,"Mine"===s?i:c,[],!1),Z=(0,n.useMemo)((()=>f.map((e=>e.id))),[f]),[y,x]=(0,de.NE)("dashboard",Z,t),[w,_]=(0,n.useState)(),[C,k]=(0,n.useState)(s),[S,E]=(0,n.useState)(!1),[$,I]=(0,n.useState)(!1),N=t=>{const a=[];return"Mine"===t?a.push({id:"owners",operator:"rel_m_m",value:`${null==e?void 0:e.userId}`}):"Favorite"===t?a.push({id:"id",operator:"dashboard_is_favorite",value:!0}):"Examples"===t&&a.push({id:"created_by",operator:"rel_o_m",value:0}),a};(0,n.useEffect)((()=>{($||"Favorite"===C)&&(e=>{v({pageIndex:0,pageSize:M.IV,sortBy:[{id:"changed_on_delta_humanized",desc:!0}],filters:N(e)})})(C),I(!0)}),[C]);const D=e=>{const t=e.map((({id:e})=>e));(0,ue.Z)("dashboard",t,(()=>{E(!1)})),E(!0)},R=[{name:"Favorite",label:(0,A.t)("Favorite"),onClick:()=>{k(le.s.FAVORITE),(0,L.LS)(L.dR.homepage_dashboard_filter,le.s.FAVORITE)}},{name:"Mine",label:(0,A.t)("Mine"),onClick:()=>{k(le.s.MINE),(0,L.LS)(L.dR.homepage_dashboard_filter,le.s.MINE)}}];return o&&R.push({name:"Examples",label:(0,A.t)("Examples"),onClick:()=>{k(le.s.EXAMPLES),(0,L.LS)(L.dR.homepage_dashboard_filter,le.s.EXAMPLES)}}),b?(0,g.tZ)(Ie,{cover:r}):(0,g.tZ)(n.Fragment,null,(0,g.tZ)(K.Z,{activeChild:C,tabs:R,buttons:[{name:(0,g.tZ)(n.Fragment,null,(0,g.tZ)("i",{className:"fa fa-plus"}),(0,A.t)("Dashboard")),buttonStyle:"tertiary",onClick:()=>{window.location.assign("/dashboard/new")}},{name:(0,A.t)("View All »"),buttonStyle:"link",onClick:()=>{const e="Favorite"===C?`/dashboard/list/?filters=(favorite:(label:${(0,A.t)("Yes")},value:!t))`:"/dashboard/list/";d.push(e)}}]}),w&&(0,g.tZ)(_e.Z,{dashboardId:null==w?void 0:w.id,show:!0,onHide:()=>_(void 0),onSubmit:e=>fe.Z.get({endpoint:`/api/v1/dashboard/${e.id}`}).then((({json:e={}})=>{h(f.map((t=>t.id===e.id?e.result:t)))}),(0,M.v$)((e=>t((0,A.t)("An error occurred while fetching dashboards: %s",e)))))}),f.length>0&&(0,g.tZ)(M._L,{showThumbnails:r},f.map((n=>(0,g.tZ)(Ce.Z,{key:n.id,dashboard:n,hasPerm:m,bulkSelectEnabled:!1,showThumbnails:r,dashboardFilter:C,refreshData:p,addDangerToast:t,addSuccessToast:a,userId:null==e?void 0:e.userId,loading:b,openDashboardEditModal:e=>_(e),saveFavoriteStatus:y,favoriteStatus:x[n.id],handleBulkDashboardExport:D})))),0===f.length&&(0,g.tZ)(W,{tableName:T.Dashboards,tab:C}),S&&(0,g.tZ)(u.Z,null))})),Se=(0,U.I)(),Ee=["2","3"],$e=p.iK.div`
  background-color: ${({theme:e})=>e.colors.grayscale.light4};
  .ant-row.menu {
    margin-top: -15px;
    background-color: ${({theme:e})=>e.colors.grayscale.light4};
    &:after {
      content: '';
      display: block;
      border: 1px solid ${({theme:e})=>e.colors.grayscale.light2};
      margin: 0px ${({theme:e})=>6*e.gridUnit}px;
      position: relative;
      width: 100%;
      ${M.mq[1]} {
        margin-top: 5px;
        margin: 0px 2px;
      }
    }
    .ant-menu.ant-menu-light.ant-menu-root.ant-menu-horizontal {
      padding-left: ${({theme:e})=>8*e.gridUnit}px;
    }
    button {
      padding: 3px 21px;
    }
  }
  .ant-card-meta-description {
    margin-top: ${({theme:e})=>e.gridUnit}px;
  }
  .ant-card.ant-card-bordered {
    border: 1px solid ${({theme:e})=>e.colors.grayscale.light2};
  }
  .ant-collapse-item .ant-collapse-content {
    margin-bottom: ${({theme:e})=>-6*e.gridUnit}px;
  }
  div.ant-collapse-item:last-child.ant-collapse-item-active
    .ant-collapse-header {
    padding-bottom: ${({theme:e})=>3*e.gridUnit}px;
  }
  div.ant-collapse-item:last-child .ant-collapse-header {
    padding-bottom: ${({theme:e})=>9*e.gridUnit}px;
  }
  .loading-cards {
    margin-top: ${({theme:e})=>8*e.gridUnit}px;
    .ant-card-cover > div {
      height: 168px;
    }
  }
`,Te=p.iK.div`
  ${({theme:e})=>`\n    display: flex;\n    justify-content: space-between;\n    height: 50px;\n    background-color: ${e.colors.grayscale.light5};\n    .welcome-header {\n      font-size: ${e.typography.sizes.l}px;\n      padding: ${4*e.gridUnit}px ${2*e.gridUnit+2}px;\n      margin: 0 ${2*e.gridUnit}px;\n    }\n    .switch {\n      display: flex;\n      flex-direction: row;\n      margin: ${4*e.gridUnit}px;\n      span {\n        display: block;\n        margin: ${1*e.gridUnit}px;\n        line-height: 1;\n      }\n    }\n  `}
`,Ie=({cover:e})=>(0,g.tZ)(M._L,{showThumbnails:e,className:"loading-cards"},[...new Array(M.iv)].map(((t,a)=>(0,g.tZ)(P.Z,{key:a,cover:!e&&(0,g.tZ)(n.Fragment,null),description:"",loading:!0})))),Ne=(0,z.ZP)((function({user:e,addDangerToast:t}){const a=e.userId.toString(),i=`/superset/recent_activity/${e.userId}/?limit=6`,[r,o]=(0,n.useState)("Loading"),d=(0,L.OH)(a,null);let l=!1;(0,q.cr)(O.T.THUMBNAILS)&&(l=void 0===(null==d?void 0:d.thumbnails)||(null==d?void 0:d.thumbnails));const[s,c]=(0,n.useState)(l),[u,b]=(0,n.useState)(null),[f,h]=(0,n.useState)(null),[m,p]=(0,n.useState)(null),[v,Z]=(0,n.useState)(null),[y,x]=(0,n.useState)(0),w=(0,L.rV)(L.dR.homepage_collapse_state,[]),[_,C]=(0,n.useState)(w),k=Se.get("welcome.banner");(0,n.useEffect)((()=>{const n=(0,L.rV)(L.dR.homepage_activity_filter,null);C(w.length>0?w:Ee),(0,M.Hn)(e.userId,i,t).then((e=>{const t={};if(t.Examples=e.examples,e.viewed){const a=R()(e.viewed,["item_url",null]).map((e=>e));t.Viewed=a,!n&&t.Viewed?o("Viewed"):n||t.Viewed?o(n||"Created"):o("Created")}else o(n||"Created");b((e=>({...e,...t})))})).catch((0,M.v$)((e=>{b((e=>({...e,Viewed:[]}))),t((0,A.t)("There was an issue fetching your recent activity: %s",e))})));const r=[{col:"created_by",opr:"rel_o_m",value:`${a}`}];(0,M.B1)(a,"dashboard").then((e=>{Z(e),x((e=>e+1))})).catch((e=>{Z([]),x((e=>e+1)),t((0,A.t)("There was an issue fetching your dashboards: %s",e))})),(0,M.B1)(a,"chart").then((e=>{h(e),x((e=>e+1))})).catch((e=>{h([]),x((e=>e+1)),t((0,A.t)("There was an issue fetching your chart: %s",e))})),(0,M.B1)(a,"saved_query",r).then((e=>{p(e),x((e=>e+1))})).catch((e=>{p([]),x((e=>e+1)),t((0,A.t)("There was an issues fetching your saved queries: %s",e))}))}),[]),(0,n.useEffect)((()=>{!w&&null!=m&&m.length&&C((e=>[...e,"4"])),b((e=>({...e,Created:[...(null==f?void 0:f.slice(0,3))||[],...(null==v?void 0:v.slice(0,3))||[],...(null==m?void 0:m.slice(0,3))||[]]})))}),[f,m,v]),(0,n.useEffect)((()=>{var e;!w&&null!=u&&null!=(e=u.Viewed)&&e.length&&C((e=>["1",...e]))}),[u]);const S=!(null!=u&&u.Examples||null!=u&&u.Viewed);return(0,g.tZ)($e,null,k&&(0,g.tZ)(k,null),(0,g.tZ)(Te,null,(0,g.tZ)("h1",{className:"welcome-header"},"Home"),(0,q.cr)(O.T.THUMBNAILS)?(0,g.tZ)("div",{className:"switch"},(0,g.tZ)(j.KU,{checked:s,onChange:()=>{c(!s),(0,L.I_)(a,{thumbnails:!s})}}),(0,g.tZ)("span",null,"Thumbnails")):null),(0,g.tZ)(F.Z,{activeKey:_,onChange:e=>{C(e),(0,L.LS)(L.dR.homepage_collapse_state,e)},ghost:!0,bigger:!0},(0,g.tZ)(F.Z.Panel,{header:(0,A.t)("Recents"),key:"1"},u&&(u.Viewed||u.Examples||u.Created)&&"Loading"!==r?(0,g.tZ)(ie,{user:{userId:e.userId},activeChild:r,setActiveChild:o,activityData:u,loadedCount:y}):(0,g.tZ)(Ie,null)),(0,g.tZ)(F.Z.Panel,{header:(0,A.t)("Dashboards"),key:"2"},!v||S?(0,g.tZ)(Ie,{cover:s}):(0,g.tZ)(ke,{user:e,mine:v,showThumbnails:s,examples:null==u?void 0:u.Examples})),(0,g.tZ)(F.Z.Panel,{header:(0,A.t)("Charts"),key:"3"},!f||S?(0,g.tZ)(Ie,{cover:s}):(0,g.tZ)(be,{showThumbnails:s,user:e,mine:f,examples:null==u?void 0:u.Examples})),(0,g.tZ)(F.Z.Panel,{header:(0,A.t)("Saved queries"),key:"4"},m?(0,g.tZ)(we,{showThumbnails:s,user:e,mine:m,featureFlag:(0,q.cr)(O.T.THUMBNAILS)}):(0,g.tZ)(Ie,{cover:s}))))})),De=(0,n.lazy)((()=>Promise.all([a.e(8782),a.e(4787)]).then(a.bind(a,28999)))),Re=(0,n.lazy)((()=>Promise.all([a.e(1216),a.e(876),a.e(8782),a.e(9502)]).then(a.bind(a,63082)))),Ue=(0,n.lazy)((()=>Promise.all([a.e(8782),a.e(1611)]).then(a.bind(a,35276)))),Ae=(0,n.lazy)((()=>Promise.all([a.e(1216),a.e(8782),a.e(665)]).then(a.bind(a,13434)))),Fe=(0,n.lazy)((()=>Promise.all([a.e(8782),a.e(9452)]).then(a.bind(a,69053)))),Le=(0,n.lazy)((()=>Promise.all([a.e(8782),a.e(8774)]).then(a.bind(a,23767)))),Pe=(0,n.lazy)((()=>Promise.all([a.e(7936),a.e(468)]).then(a.bind(a,82343)))),ze=(0,n.lazy)((()=>Promise.all([a.e(8782),a.e(4502)]).then(a.bind(a,30075)))),Me=(0,n.lazy)((()=>Promise.all([a.e(8782),a.e(5656)]).then(a.bind(a,97894)))),qe=(0,n.lazy)((()=>Promise.all([a.e(8782),a.e(9137)]).then(a.bind(a,25163)))),Oe=(0,n.lazy)((()=>Promise.all([a.e(1216),a.e(876),a.e(2671),a.e(1139),a.e(323),a.e(8274),a.e(2308),a.e(9541)]).then(a.bind(a,39069)))),je=(0,n.lazy)((()=>Promise.all([a.e(8782),a.e(4173),a.e(7633)]).then(a.bind(a,82842)))),Ve=[{path:"/superset/welcome/",Component:Ne},{path:"/dashboard/list/",Component:Le},{path:"/superset/dashboard/:idOrSlug/",Component:Pe},{path:"/chart/list/",Component:Ae},{path:"/tablemodelview/list/",Component:Me},{path:"/databaseview/list/",Component:ze},{path:"/savedqueryview/list/",Component:(0,n.lazy)((()=>Promise.all([a.e(8782),a.e(4173),a.e(9173)]).then(a.bind(a,49588))))},{path:"/csstemplatemodelview/list/",Component:Fe},{path:"/annotationlayermodelview/list/",Component:De},{path:"/annotationmodelview/:annotationLayerId/annotation/",Component:Ue},{path:"/superset/sqllab/history/",Component:je},{path:"/alert/list/",Component:Re},{path:"/report/list/",Component:Re,props:{isReportEnabled:!0}},{path:"/alert/:alertId/log/",Component:qe},{path:"/report/:alertId/log/",Component:qe,props:{isReportEnabled:!0}},{path:"/explore/",Component:Oe},{path:"/superset/explore/p",Component:Oe}],Be=Ve.map((e=>e.path)).reduce(((e,t)=>({...e,[t]:!0})),{});function Ke(e){if(e){const t=e.split(/[?#]/)[0];return!!Be[t]}return!1}var He=a(3741),Qe=a(68135),Ye=a(35755),Xe=a(38626),We=a(57865),Ge=a(77291),Je=a(33626);const et={info:"addInfoToast",alert:"addDangerToast",danger:"addDangerToast",warning:"addWarningToast",success:"addSuccessToast"};function tt({children:e,messages:t}){const a=(0,z.e1)();return(0,Je.J)((()=>{t.forEach((e=>{const[t,n]=e,i=a[et[t]];i&&i(n)}))})),e}var at=a(29147),nt=a(14278);const it={...f.b.common},rt=({children:e})=>(0,g.tZ)(Qe.a,{theme:f.r},(0,g.tZ)(m.zt,{store:Ge.h},(0,g.tZ)(Xe.W,{backend:We.PD},(0,g.tZ)(tt,{messages:it.flash_messages},(0,g.tZ)(at.DG,null,(0,g.tZ)(nt.EM,null,(0,g.tZ)(Ye.Fz,{ReactRouterRoute:l.AW,stringifyOptions:{encode:!1}},e)))))));(0,I.Z)(),(0,N.Z)();const ot={...f.b.user},dt={...f.b.common.menu_data};let lt;const st=()=>{const e=(0,l.TH)();return(0,n.useEffect)((()=>{lt&&lt!==e.pathname&&He.Yd.markTimeOrigin(),lt=e.pathname}),[e.pathname]),(0,g.tZ)(n.Fragment,null)};i.render((0,g.tZ)((()=>(0,g.tZ)(d.VK,null,(0,g.tZ)(st,null),(0,g.tZ)(rt,null,(0,g.tZ)(s.n,null),(0,g.tZ)(b.Z,{data:dt,isFrontendRoute:Ke}),(0,g.tZ)(l.rs,null,Ve.map((({path:e,Component:t,props:a={},Fallback:i=u.Z})=>(0,g.tZ)(l.AW,{path:e,key:e},(0,g.tZ)(n.Suspense,{fallback:(0,g.tZ)(i,null)},(0,g.tZ)(c.Z,null,(0,g.tZ)(t,o()({user:ot},a)))))))),(0,g.tZ)($,null)))),null),document.getElementById("app"))}},s={};function c(e){var t=s[e];if(void 0!==t)return t.exports;var a=s[e]={id:e,loaded:!1,exports:{}};return l[e].call(a.exports,a,a.exports,c),a.loaded=!0,a.exports}c.m=l,c.amdD=function(){throw new Error("define cannot be used indirect")},c.amdO={},e=[],c.O=(t,a,n,i)=>{if(!a){var r=1/0;for(s=0;s<e.length;s++){for(var[a,n,i]=e[s],o=!0,d=0;d<a.length;d++)(!1&i||r>=i)&&Object.keys(c.O).every((e=>c.O[e](a[d])))?a.splice(d--,1):(o=!1,i<r&&(r=i));if(o){e.splice(s--,1);var l=n();void 0!==l&&(t=l)}}return t}i=i||0;for(var s=e.length;s>0&&e[s-1][2]>i;s--)e[s]=e[s-1];e[s]=[a,n,i]},c.H={},c.G=e=>{Object.keys(c.H).map((t=>{c.H[t](e)}))},c.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e;return c.d(t,{a:t}),t},a=Object.getPrototypeOf?e=>Object.getPrototypeOf(e):e=>e.__proto__,c.t=function(e,n){if(1&n&&(e=this(e)),8&n)return e;if("object"==typeof e&&e){if(4&n&&e.__esModule)return e;if(16&n&&"function"==typeof e.then)return e}var i=Object.create(null);c.r(i);var r={};t=t||[null,a({}),a([]),a(a)];for(var o=2&n&&e;"object"==typeof o&&!~t.indexOf(o);o=a(o))Object.getOwnPropertyNames(o).forEach((t=>r[t]=()=>e[t]));return r.default=()=>e,c.d(i,r),i},c.d=(e,t)=>{for(var a in t)c.o(t,a)&&!c.o(e,a)&&Object.defineProperty(e,a,{enumerable:!0,get:t[a]})},c.f={},c.e=e=>Promise.all(Object.keys(c.f).reduce(((t,a)=>(c.f[a](e,t),t)),[])),c.u=e=>4593===e?"4593.33a0684cd58e280de63d.entry.js":2441===e?"2441.e382b08eeef51597bf71.entry.js":323===e?"323.bb775c407e56e0a46fc9.entry.js":{57:"38f4b0c5b2c751f3029f",112:"0cceda87f254629c0f55",137:"2e4eee61fdab260331a3",158:"7af34d924b2b2e3aaaa7",177:"ca39eb74c4d49fd55005",183:"2d69e60dfe962c42eee9",215:"b454f5a5787644b6f329",310:"e2c18a71d3a5c875a789",312:"90af13ee4a0d5e067aab",326:"2394871e83d5034c5318",336:"e5df42bc5a8ad6d9aed0",347:"3f1f3f38b6b3b9616e75",349:"0202ec1626f196ac9881",363:"e517ebae29a6c51c5e09",380:"3e77639050e91d2c0630",440:"163404f983dce20259a1",444:"eebc4df9b567ec2657cd",452:"fd4f609314ff299a45b7",468:"0e11dbbc5a096ae74d29",498:"04c19f92943ed9b4ddb9",597:"d08e416f0ccd4854221a",600:"d0d66aaabc04eac7f3a8",616:"a77417ca34a51fe13a7d",665:"3f608e1de859a8901191",704:"56bff0d3ef19079ea66f",741:"ddfd188cfe976cc863f1",775:"3530fba743ac26563709",826:"3f59c315d2e5d8b15ff9",876:"37176dbdd5e6ae3abd2e",954:"96328cc7910404deebe6",992:"3972b8e3abebd6e63caf",999:"54febe7bb96630a3013d",1020:"b190f9aca679c03b62c3",1075:"529bc3f823e6fc60cd70",1095:"d9afdc3949f8b21a7820",1130:"110ae26061868bd68c17",1139:"149758d1a79bd7eafa7e",1161:"3aa46fb33df2aab20c02",1174:"8849a375bcccf9df44ed",1185:"9ea89afc9bce89ad80ad",1221:"993aec5382375e76b579",1256:"3479cded7646565257ab",1258:"604b6fdb6661c6e1205e",1261:"858915f2b7f5a9a59fc3",1263:"62048be321505812ff6a",1293:"825c8594d240fbf17f20",1336:"2f57608a13a773620715",1351:"8f38137e5b4342d2da4f",1382:"4c5c4c09ba5f63220889",1398:"951f07c7c3e07b72cca4",1402:"308402927cb1af91614e",1493:"55bdc0586c89caac178c",1568:"40f6c6e7fe72a2bc1b13",1573:"2e576b04c9b82c938093",1605:"2f7a1d1a47b76ec8c5c1",1611:"2fe1dea5911642bdfb0a",1862:"efa4dee9ae5b2791880f",1877:"7dd385c6e9090a1b2734",1899:"0502b5cdba557a6ff693",1948:"5073b8639a819d94f04c",2079:"1506fd7de5b75c690b36",2089:"6762245ee484d3ffcb17",2105:"8146230ef7c416ab6cb3",2112:"bd47c3047ff30d422b26",2229:"92b5dd2bef5c7f4c0f0c",2264:"b12e914fd5684cf329c8",2267:"1665a22356999f7d09cb",2308:"3752b124eb447aa02563",2403:"a0d676c094e2f90b5f0a",2439:"7e0114c1e26108fed2fc",2549:"b939e874d4289ca1bb4f",2646:"22d6b0b1d527d046d260",2671:"4efbb61faace28861a36",2698:"75dfd37839ade6c35680",2713:"617726f17984c3192f46",2797:"6a8bfc332a16fd0f491c",2955:"21b0680368dea0bf61c5",2983:"b85bf5c0e81e6910fa04",3036:"d5b933a93d6a34a0920b",3126:"3ceba30a110289622d79",3141:"6db0cd2a326a62903532",3187:"6802e173609e0f6b30c1",3208:"dafb5933827b1aa398f0",3232:"bdbff878e978bfd6ee9f",3240:"78cb567a5b91a58f0c01",3265:"edc982d88e8d399830b7",3325:"46b72d4c661fb47189a2",3496:"bbde815936f983fdf562",3544:"78f16a06c10598e0b889",3558:"a1e4af25d87548162409",3567:"ccb341a117b2ee4d5e98",3588:"461c58b164a3fc1357b1",3606:"7621f705e25335f0121d",3711:"78a94e1e858a8721ed5f",3716:"eb7a4192bd807a2e4e94",3745:"19220130e12f15e5cce8",3749:"68f7a3e5d439a23f4d89",3831:"0a48200ca8cf0d470682",3871:"79cd11ca09fe747b1bfd",3955:"03c4e9c66c2c63d79acc",3985:"d51bceddde4bd627d6c2",4139:"21f4237f0879646a0d9c",4173:"9c70a4f493ee0f96713f",4194:"89e3dd82524d881e7dd7",4237:"f3af87387b276d765b99",4266:"958a29639679b362fba3",4273:"827fb5197c686f0662c7",4421:"6290fd574418d5e32572",4458:"85219e9a6edf20621bea",4474:"b28a000dfeccbe1d81f3",4494:"17d08cbf2796684120c5",4502:"80d1a952d07e7c1c568e",4572:"d829638677a496dd2bf5",4579:"8164718d6dabba184b88",4625:"7c5442bc1e5598e90822",4662:"712187ae25c83dce2174",4667:"47a4c2c13ccfb09d3757",4732:"d30d055df1b3b7e84dba",4757:"124ced191b8ef59a3e2c",4758:"8546effff2a679b01358",4787:"a8c4ff3a1142b26a09c9",4790:"8546d26839292e046adb",4794:"fa2a3ad4d82d3d4459fd",4797:"be22f9be14d0445f0f87",4810:"82297ac94bca3b3859d2",4817:"259525e7b455b997848a",4832:"5a592d69bbd6eff5fd66",4851:"a9ccd9b9ba2b847b6417",4972:"132e72e310c461806395",5051:"86881151df595df4d35b",5094:"e6dca6d844421aa773c2",5123:"9d063c72a9891c56cbdc",5181:"316fc856455d7413753c",5201:"0c0d33390c8cfa65fbbd",5215:"20dcf5c795803b21389a",5224:"2137b5c272446c93f5b7",5226:"43d2d046df38601d76af",5249:"8c40bbdfb03d04b29d02",5264:"764ad1c6642ad40a50d2",5281:"8b441b46691123854b6b",5330:"c3630bd2c65829e4c7a1",5335:"cbdabbf1e2d3d7e254df",5350:"a4556551303ff93cd4bb",5359:"fe8715215a93c63953ec",5367:"12541bbb82603d7e2d66",5507:"c7cdf6f84afbcf502ddb",5566:"fda64d8ef587e311d62e",5580:"fa964e628191e708a48e",5592:"2e19c97690b06c32f1b4",5641:"207a4252758bcd4d3cbd",5656:"8e892d0d1be4ed413f3c",5707:"2b76605f1d6e11cf2df7",5771:"3acf2091ed043492ae76",5777:"58d0e720fba584974cbf",5802:"8caa85ec5eb98cb83343",5816:"3374bb9b8c7f89ae2da0",5818:"acf48310a13b7cb1a79c",5832:"6641ca7ff6e2a41a1257",5838:"af5789397b8a13e08c38",5962:"ed92d26f4a929fbbc564",5972:"713e574a1d9b58a2135d",5998:"cb935545042c1ce92ecb",6061:"c9b07a9f1a9bae8552b2",6126:"62a79c1241ef166355de",6150:"6d17f8394d91a097eab6",6167:"ad4ff700d252caec8ce3",6207:"17d778c7ae36315bd979",6254:"15612e9a43534ba1a97d",6303:"b8e13b4773cab5f877ee",6357:"b70dcdf0427abc91ad57",6371:"150eda30c7d4d3f90b81",6377:"6f0f091efb5ecc18dde4",6420:"12131f944d05bfbc2b3d",6447:"bfa0e245c6ade68dd3de",6486:"9801caf1364f204340c9",6507:"f00932e24ce22bd1ca3b",6579:"59f16731ccd9acdd96b3",6611:"3fe355027890c4cf2c7c",6668:"0062637c2e307e4a2536",6682:"bdf3637ab1584c67ae30",6693:"7859419c833807d8ecc8",6758:"fc3f2d7bb3a5b8f56817",6819:"1d34427183b1bc32acfd",6871:"ee6aaef556c2b3abedbf",6883:"369bb61eda9423d64359",6968:"626e60cd5099d84de454",6981:"68a6c50b90b0d58736ad",7003:"40ed9de7bc516276c805",7183:"e16648fac64644e729c7",7245:"68eaaf3112a48224bf50",7249:"b5e7e83ac26bf4ec5fbe",7405:"2bfae0bdc72a5900199c",7460:"140aaba41af8a7b3891b",7521:"26996cc765c12c03e878",7584:"76c89f632c7a8315389e",7610:"69ae28e81db50e4eb6d7",7633:"bffd99140052d0d27b12",7654:"2a756f12d13ca404a744",7716:"36cbf8b4562f9c80a2e0",7760:"7ab09485b0ef9d161fbf",7803:"7967d211212f85a80dde",7832:"fd7f701b105cdaddf11a",7850:"00845228665a5b4e5deb",7922:"034a466af79e5aec1e20",7936:"e668eb98aaaf5211d3ef",7974:"06bf28d669c5be88c75e",7984:"aab98ca4cfcb982e0aca",7989:"e2c714d33a44d93648c0",8041:"b0b7ebae013a28bd3488",8274:"83609c2078ddfdb2c272",8312:"9b8eaa85fdf772d344ca",8349:"739a4da1e29881e55220",8398:"effe2e4690559c9dd638",8425:"d93b4ec64b1aced0c856",8463:"55fba49f8743cb008b18",8464:"a83dd00ddeaff36a6d15",8491:"bc7fc77e4b9a26daf89a",8551:"e0f8ea080fcddb4932d6",8623:"f3f0b0e4997f9dcf5264",8650:"0397d3d0734fd9230e1b",8656:"930c6a0cab67c68681cd",8682:"e55361dd9642ab2c6cce",8695:"794b59e83f2639bbd4f5",8701:"ac60e542441acfc7d1ff",8750:"a4875cd79305e6148ef1",8774:"538e9b5a7a58a16d007c",8782:"4bf328fc9b4720ccc57d",8883:"7d0a7cd57a0e5306d21e",8924:"2b7dda01776b3d7cfd73",8970:"9662eb9aee235b45a0ba",9013:"2ae202ac00476dac5f77",9052:"bdc47b9882987a855bd3",9101:"407494e415e017cbfdd9",9109:"70032121a681b08c1ca9",9137:"6a141e95f7538f120b15",9173:"471368caf506a8038326",9207:"5716fdaacba60c1b00fc",9305:"857144aa3240952e069c",9313:"f002dd41453444b5a5f0",9322:"4c640e97a929f739a3df",9325:"d2f1f08edbd1d07cd106",9393:"aa0534433005d1a82b09",9396:"1f863758a649c6e62a7b",9452:"696071056066e32f9196",9483:"7c5a3f384fdb6adcc304",9502:"2e9e730f09642685fa9e",9510:"a1ded01332afd173d7e1",9541:"4460a6513f7de8e96bc7",9558:"11464bec3d82809a0027",9622:"a6e817b0d68ef7cee2d4",9767:"9e8414a89898cf629e48",9794:"6c8b7483e1f99924e7f5",9811:"b3748ff012fc7ee520ef",9857:"169119af235c81fa0bc3",9873:"34c9f3b849b55ef12fa4",9877:"5735cc672f1cdb57b707"}[e]+".chunk.js",c.miniCssF=e=>(({452:"DashboardContainer",9502:"AlertList",9541:"ExplorePage"}[e]||e)+"."+{137:"2e4eee61fdab260331a3",380:"3e77639050e91d2c0630",452:"fd4f609314ff299a45b7",1261:"858915f2b7f5a9a59fc3",1877:"7dd385c6e9090a1b2734",3036:"d5b933a93d6a34a0920b",4194:"89e3dd82524d881e7dd7",4237:"f3af87387b276d765b99",4494:"17d08cbf2796684120c5",5566:"fda64d8ef587e311d62e",6871:"ee6aaef556c2b3abedbf",8623:"f3f0b0e4997f9dcf5264",8650:"0397d3d0734fd9230e1b",9313:"f002dd41453444b5a5f0",9502:"2e9e730f09642685fa9e",9541:"4460a6513f7de8e96bc7"}[e]+".chunk.css"),c.g=function(){if("object"==typeof globalThis)return globalThis;try{return this||new Function("return this")()}catch(e){if("object"==typeof window)return window}}(),c.hmd=e=>((e=Object.create(e)).children||(e.children=[]),Object.defineProperty(e,"exports",{enumerable:!0,set:()=>{throw new Error("ES Modules may not assign module.exports or exports.*, Use ESM export syntax, instead: "+e.id)}}),e),c.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),n={},i="superset:",c.l=(e,t,a,r)=>{if(n[e])n[e].push(t);else{var o,d;if(void 0!==a)for(var l=document.getElementsByTagName("script"),s=0;s<l.length;s++){var u=l[s];if(u.getAttribute("src")==e||u.getAttribute("data-webpack")==i+a){o=u;break}}o||(d=!0,(o=document.createElement("script")).charset="utf-8",o.timeout=120,c.nc&&o.setAttribute("nonce",c.nc),o.setAttribute("data-webpack",i+a),o.src=e),n[e]=[t];var b=(t,a)=>{o.onerror=o.onload=null,clearTimeout(f);var i=n[e];if(delete n[e],o.parentNode&&o.parentNode.removeChild(o),i&&i.forEach((e=>e(a))),t)return t(a)},f=setTimeout(b.bind(null,void 0,{type:"timeout",target:o}),12e4);o.onerror=b.bind(null,o.onerror),o.onload=b.bind(null,o.onload),d&&document.head.appendChild(o)}},c.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},c.nmd=e=>(e.paths=[],e.children||(e.children=[]),e),c.p="/static/assets/",r=e=>new Promise(((t,a)=>{var n=c.miniCssF(e),i=c.p+n;if(((e,t)=>{for(var a=document.getElementsByTagName("link"),n=0;n<a.length;n++){var i=(o=a[n]).getAttribute("data-href")||o.getAttribute("href");if("stylesheet"===o.rel&&(i===e||i===t))return o}var r=document.getElementsByTagName("style");for(n=0;n<r.length;n++){var o;if((i=(o=r[n]).getAttribute("data-href"))===e||i===t)return o}})(n,i))return t();((e,t,a,n)=>{var i=document.createElement("link");i.rel="stylesheet",i.type="text/css",i.onerror=i.onload=r=>{if(i.onerror=i.onload=null,"load"===r.type)a();else{var o=r&&("load"===r.type?"missing":r.type),d=r&&r.target&&r.target.href||t,l=new Error("Loading CSS chunk "+e+" failed.\n("+d+")");l.code="CSS_CHUNK_LOAD_FAILED",l.type=o,l.request=d,i.parentNode.removeChild(i),n(l)}},i.href=t,document.head.appendChild(i)})(e,i,t,a)})),o={7103:0},c.f.miniCss=(e,t)=>{o[e]?t.push(o[e]):0!==o[e]&&{137:1,380:1,452:1,1261:1,1877:1,3036:1,4194:1,4237:1,4494:1,5566:1,6871:1,8623:1,8650:1,9313:1,9502:1,9541:1}[e]&&t.push(o[e]=r(e).then((()=>{o[e]=0}),(t=>{throw delete o[e],t})))},(()=>{var e={7103:0};c.f.j=(t,a)=>{var n=c.o(e,t)?e[t]:void 0;if(0!==n)if(n)a.push(n[2]);else if(/^(126|687)1$/.test(t))e[t]=0;else{var i=new Promise(((a,i)=>n=e[t]=[a,i]));a.push(n[2]=i);var r=c.p+c.u(t),o=new Error;c.l(r,(a=>{if(c.o(e,t)&&(0!==(n=e[t])&&(e[t]=void 0),n)){var i=a&&("load"===a.type?"missing":a.type),r=a&&a.target&&a.target.src;o.message="Loading chunk "+t+" failed.\n("+i+": "+r+")",o.name="ChunkLoadError",o.type=i,o.request=r,n[1](o)}}),"chunk-"+t,t)}},c.H.j=t=>{if(!(c.o(e,t)&&void 0!==e[t]||/^(126|687)1$/.test(t))){e[t]=null;var a=document.createElement("link");a.charset="utf-8",c.nc&&a.setAttribute("nonce",c.nc),a.rel="preload",a.as="script",a.href=c.p+c.u(t),document.head.appendChild(a)}},c.O.j=t=>0===e[t];var t=(t,a)=>{var n,i,[r,o,d]=a,l=0;if(r.some((t=>0!==e[t]))){for(n in o)c.o(o,n)&&(c.m[n]=o[n]);if(d)var s=d(c)}for(t&&t(a);l<r.length;l++)i=r[l],c.o(e,i)&&e[i]&&e[i][0](),e[r[l]]=0;return c.O(s)},a=globalThis.webpackChunksuperset=globalThis.webpackChunksuperset||[];a.forEach(t.bind(null,0)),a.push=t.bind(null,a.push.bind(a))})(),d={468:[1216,876,995,2671,1139,8274,2308,5857,452]},c.f.preload=e=>{var t=d[e];Array.isArray(t)&&t.map(c.G)},c.O(void 0,[1216,504,7550,2102,3018,250,7167,2087,6836,1844,6975,3166,995,9602,2452,5010,4113,8868,5481,5175,2569,2120,7877,7230,5857],(()=>c(35260)));var u=c.O(void 0,[1216,504,7550,2102,3018,250,7167,2087,6836,1844,6975,3166,995,9602,2452,5010,4113,8868,5481,5175,2569,2120,7877,7230,5857],(()=>c(71644)));u=c.O(u)})();
//# sourceMappingURL=spa.f5618ee95d431be42b0f.entry.js.map